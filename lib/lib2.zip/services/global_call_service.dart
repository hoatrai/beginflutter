import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../app_globals.dart'; // navigatorKey, fetchMe
import '../pages/video_call_page.dart';
import '../pages/webrtc_signal_bus.dart';

/// GlobalCallService — singleton sống suốt vòng đời app.
///
/// **Mục đích**: Hiện màn hình "có cuộc gọi đến" bất kể user đang ở trang nào
/// (home, shop, map, ...) hoặc vừa mở app từ background qua FCM.
///
/// **Luồng**:
/// 1. Server nhận `call_invite` từ người gọi → gửi FCM data-only message
///    đến thiết bị người nhận với:
///      { "type": "video_call", "from_id": "...", "from_name": "...",
///        "from_avatar": "...", "topic": "room:chat_X_Y" }
/// 2. `setupFirebaseMessaging()` trong main.dart gọi
///    `GlobalCallService.instance.handleFcmCall(message.data)` khi nhận FCM.
/// 3. Service mở kết nối WebSocket phụ đến đúng topic, sau đó hiện overlay.
/// 4. User bấm "Nghe" → gửi `call_accept` qua WS phụ + mở VideoCallPage.
/// 5. User bấm "Từ chối" → gửi `call_reject` qua WS phụ + đóng overlay.
/// 6. Người gọi hủy (`call_end`) → service tự đóng overlay.
///
/// Nếu user **đang mở ChatPage** đúng cuộc trò chuyện đó, ChatPage vẫn hiện
/// overlay của chính nó (vì nó nhận `call_invite` qua WebSocket của nó).
/// GlobalCallService sẽ kiểm tra `isChatPageOpen` và bỏ qua để không hiện 2
/// overlay cùng lúc.
class GlobalCallService {
  GlobalCallService._();
  static final GlobalCallService instance = GlobalCallService._();

  // ---- state ----
  OverlayEntry? _overlay;
  VoidCallback? _dismissOverlay;
  WebSocketChannel? _callChannel;
  Stream<dynamic>? _broadcastStream;
  int _refCounter = 9000; // tránh trùng ref với ChatPage
  String? _activeTopic;
  Timer? _autoDismissTimer;
  StreamSubscription? _wsSub;

  // ---------------------------------------------------------------
  // PUBLIC API
  // ---------------------------------------------------------------

  /// Gọi từ setupFirebaseMessaging khi nhận FCM có type == "video_call".
  Future<void> handleFcmCall(Map<String, dynamic> data) async {
    final fromName = data['from_name'] ?? 'Ai đó';
    final fromAvatar = data['from_avatar'] as String?;
    final topic = data['topic'] as String?;

    if (topic == null) return;

    // Nếu user đang mở đúng ChatPage của cuộc trò chuyện này,
    // ChatPage tự xử lý → service không làm gì thêm.
    if (isChatPageOpen) return;

    // Mở kết nối WebSocket phụ để gửi accept/reject/call_end về server.
    await _connectCallChannel(topic);

    _showOverlay(fromName: fromName, fromAvatar: fromAvatar, topic: topic);
  }

  // ---------------------------------------------------------------
  // PRIVATE
  // ---------------------------------------------------------------

  Future<void> _connectCallChannel(String topic) async {
    // Đóng kết nối cũ nếu còn sót lại từ cuộc gọi trước.
    await _closeCallChannel();

    _activeTopic = topic;

    try {
      _callChannel = WebSocketChannel.connect(
        Uri.parse("wss://socket.spiritwebs.com/socket/websocket"),
      );

      // Join topic
      _callChannel!.sink.add(jsonEncode({
        "topic": topic,
        "event": "phx_join",
        "payload": {},
        "ref": "${_refCounter++}",
      }));

      // Dùng broadcast stream để có thể listen nhiều lần (VideoCallPage cũng cần)
      final broadcastStream = _callChannel!.stream.asBroadcastStream();
      _broadcastStream = broadcastStream;

      // Lắng nghe call_end từ người gọi (họ hủy trước khi mình bấm)
      // Đồng thời forward signal WebRTC cho bus (dùng khi VideoCallPage đã mở)
      _wsSub = broadcastStream.listen(
            (data) {
          _onChannelData(data);
          WebRTCSignalBus.instance.handle(data);
        },
        onError: (_) {},
        onDone: () {},
      );
    } catch (e) {
      debugPrint("GlobalCallService: WS connect error: $e");
    }
  }

  void _onChannelData(dynamic data) {
    try {
      final msg = jsonDecode(data as String);
      final event = msg['event'];
      if (event == 'call_end' || event == 'call_reject') {
        _dismissOverlay?.call();
      }
    } catch (_) {}
  }

  void _send(String event, Map payload) {
    if (_callChannel == null || _activeTopic == null) return;
    _callChannel!.sink.add(jsonEncode({
      "topic": _activeTopic,
      "event": event,
      "payload": payload,
      "ref": "${_refCounter++}",
    }));
  }

  Future<void> _closeCallChannel() async {
    _wsSub?.cancel();
    _wsSub = null;
    await _callChannel?.sink.close();
    _callChannel = null;
    _activeTopic = null;
  }

  void _showOverlay({
    required String fromName,
    String? fromAvatar,
    required String topic,
  }) {
    // Hủy overlay cũ nếu có (double-call guard)
    _dismissOverlay?.call();

    // Phát chuông
    FlutterRingtonePlayer().play(
      android: AndroidSounds.ringtone,
      ios: IosSounds.glass,
      looping: true,
      volume: 0.7,
      asAlarm: false,
    );

    final overlayState = navigatorKey.currentState?.overlay;
    if (overlayState == null) return;

    late AnimationController controller;

    bool _accepted = false;

    void dismiss() {
      FlutterRingtonePlayer().stop();
      _autoDismissTimer?.cancel();
      controller.reverse().then((_) {
        _overlay?.remove();
        _overlay = null;
        _dismissOverlay = null;
        controller.dispose();
        // Nếu user bấm Nghe thì KHÔNG close channel — VideoCallPage đang dùng nó
        if (!_accepted) _closeCallChannel();
      });
    }
    _dismissOverlay = dismiss;

    _overlay = OverlayEntry(
      builder: (ctx) => _GlobalCallBanner(
        fromName: fromName,
        avatarUrl: fromAvatar,
        onCreateController: (c) => controller = c,
        onAccept: () async {
          // Gửi call_accept trước khi dismiss (dismiss sẽ gọi _closeCallChannel)
          _accepted = true; // ngăn dismiss() close channel
          _send("call_accept", {});

          // Giữ lại _callChannel để dùng cho VideoCallPage
          // (KHÔNG close ở đây — VideoCallPage sẽ dùng nó để trao đổi WebRTC signal)
          final activeChannel = _callChannel;
          final activeTopic = _activeTopic;

          // Reset state của service nhưng KHÔNG đóng channel
          _wsSub?.cancel();
          _wsSub = null;
          _callChannel = null;
          _activeTopic = null;

          dismiss(); // stop chuông + ẩn overlay (không close channel nữa)

          if (activeChannel == null || activeTopic == null) return;

          // Gắn channel vào signal bus để WebRTC signal đi qua đúng kênh
          WebRTCSignalBus.instance.bindSocket(
            channel: activeChannel,
            topicName: activeTopic,
          );

          // Signal đã được forward qua WebRTCSignalBus bởi _wsSub (broadcast stream).
          // KHÔNG listen lại activeChannel.stream — single-subscription đã bị bind.

          navigatorKey.currentState?.push(
            MaterialPageRoute(
              builder: (_) => VideoCallPage(
                socket: activeChannel,
                topic: activeTopic,
                isCaller: false,
              ),
            ),
          );
        },
        onReject: () {
          dismiss();
          _send("call_reject", {});
        },
      ),
    );

    overlayState.insert(_overlay!);

    // Tự ẩn sau 30s nếu không ai bấm gì
    _autoDismissTimer = Timer(const Duration(seconds: 30), () {
      _dismissOverlay?.call();
    });
  }
}

// ---------------------------------------------------------------------------
// Banner widget — copy style từ _IncomingCallBanner trong chat_page.dart
// nhưng độc lập (không cần context của ChatPage).
// ---------------------------------------------------------------------------

class _GlobalCallBanner extends StatefulWidget {
  final String fromName;
  final String? avatarUrl;
  final VoidCallback onAccept;
  final VoidCallback onReject;
  final void Function(AnimationController) onCreateController;

  const _GlobalCallBanner({
    required this.fromName,
    required this.avatarUrl,
    required this.onAccept,
    required this.onReject,
    required this.onCreateController,
  });

  @override
  State<_GlobalCallBanner> createState() => _GlobalCallBannerState();
}

class _GlobalCallBannerState extends State<_GlobalCallBanner>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _slide = Tween<Offset>(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));

    widget.onCreateController(_ctrl);
    _ctrl.forward();
  }

  @override
  void dispose() {
    // controller bị dispose bởi GlobalCallService._showOverlay sau reverse()
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;

    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: SlideTransition(
        position: _slide,
        child: Material(
          color: Colors.transparent,
          child: Container(
            margin: EdgeInsets.fromLTRB(10, topPad + 6, 10, 0),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xF21C1C1E),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.28),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                child: Row(
                  children: [
                    // Avatar
                    CircleAvatar(
                      radius: 22,
                      backgroundColor: Colors.white24,
                      backgroundImage: (widget.avatarUrl?.isNotEmpty ?? false)
                          ? NetworkImage(widget.avatarUrl!)
                          : null,
                      child: (widget.avatarUrl?.isNotEmpty ?? false)
                          ? null
                          : const Icon(Icons.person,
                          color: Colors.white70, size: 22),
                    ),
                    const SizedBox(width: 12),

                    // Tên + subtitle
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.fromName,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.videocam_rounded,
                                  size: 13, color: Colors.greenAccent),
                              SizedBox(width: 4),
                              Text(
                                "Cuộc gọi video đến...",
                                style: TextStyle(
                                  color: Colors.white60,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Nút Từ chối
                    _CallButton(
                      icon: Icons.call_end,
                      color: Colors.redAccent,
                      onTap: widget.onReject,
                    ),
                    const SizedBox(width: 10),

                    // Nút Nghe
                    _CallButton(
                      icon: Icons.videocam_rounded,
                      color: Colors.greenAccent,
                      onTap: widget.onAccept,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CallButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _CallButton({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: color.withOpacity(0.18),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: color, size: 22),
      ),
    );
  }
}