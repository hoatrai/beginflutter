import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../helpers/storage_helper.dart';
import '../app_globals.dart';
import 'login_page.dart';
import '../main.dart';
import 'set_password_page.dart';
import 'package:shimmer/shimmer.dart' as shimmer;

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    _init();
  }

  void _goSetPassword() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const SetPasswordPage()),
    );
  }

  Future<void> _init() async {
    final token = await StorageHelper.read("jwt_token");

    if (token != null) {
      final me = await fetchMe();

      if (me == null || me['logged_in'] != true) {
        await StorageHelper.clear();
        _goLogin(); // 🔥 PHẢI RETURN
        return;
      }

      // ✅ LƯU LẠI USER STATE (RẤT QUAN TRỌNG)
      await StorageHelper.write("user_id", me['id'].toString());
      await StorageHelper.write("user_data", jsonEncode(me));

      if (me['must_set_password'] == true) {
        _goSetPassword();
        return;
      }

      _goMain();
      return;
    }

    // ❗ CHỈ guest-login khi KHÔNG có token
    final ok = await _guestLogin();
    if (ok) {
      _goMain();
    } else {
      _goLogin();
    }
  }


  Future<bool> _guestLogin() async {
    try {
      final res = await http.post(
        Uri.parse("https://spiritwebs.com/wp-json/spiritwebs/v1/guest-login"),
      );

      if (res.statusCode != 200) return false;

      final data = jsonDecode(res.body);

      if (data['token'] == null || data['user_id'] == null) return false;

      await StorageHelper.write("jwt_token", data['token']);
      await StorageHelper.write("user_id", data['user_id'].toString());
      await StorageHelper.write("user_data", jsonEncode(data['user']));
      await StorageHelper.write("is_guest", data['is_guest'].toString());

      return true;
    } catch (_) {
      return false;
    }
  }

  void _goMain() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const MainPage()),
    );
  }

  void _goLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: shimmer.Shimmer.fromColors(
          baseColor: Colors.grey.shade800,
          highlightColor: Colors.grey.shade600,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 🔥 Logo placeholder
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              const SizedBox(height: 24),

              // 🔥 Text placeholder
              Container(
                width: 160,
                height: 18,
                color: Colors.white,
              ),
              const SizedBox(height: 12),
              Container(
                width: 120,
                height: 14,
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}