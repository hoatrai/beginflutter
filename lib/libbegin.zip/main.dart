import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'helpers/lifecycle_tracker.dart';
import 'helpers/storage_helper.dart';
import 'pages/profile_page.dart';
import 'pages/shop_page.dart';
import 'pages/flutter_map.dart';
import 'pages/group_page.dart';
import 'pages/create_invite_page.dart';
import 'pages/splash_page.dart';
import 'pages/product_detail_page.dart';
import 'pages/chat_page.dart';
import 'pages/notification_store.dart';
//import 'pages/notification_page.dart';

// ---------------- GLOBAL STATE ----------------
// NOTE: these are kept as top-level singletons to match the original
// architecture (used by both the FCM handlers and the UI). For a larger
// app these are good candidates to move into a dedicated NotificationService
// class, but that's a structural change beyond a bug-fix pass.

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
final ValueNotifier<int> unreadNotiVN = ValueNotifier<int>(0);

String? pendingKeoId;
OverlayEntry? _appNotificationOverlay;
Timer? _notificationDismissTimer;

// Used by chat_page.dart to flag whether the chat screen is currently
// open, e.g. so incoming chat push notifications can be suppressed/handled
// differently while the user is already inside the chat.
bool isChatPageOpen = false;

/// WooCommerce credentials used to look up "kèo" (invite/product) details
/// from a push notification deep link.
///
/// ⚠️ SECURITY: these are shipped inside the compiled app, which means
/// anyone can extract them by decompiling the APK/IPA. Ideally this lookup
/// should go through your own backend (which holds the secret), with the
/// app only calling your API and never seeing the WooCommerce secret.
class WooCommerceConfig {
  static const consumerKey = 'ck_3809ad31dd47ca7d10573e35ccdf746494b305a9';
  static const consumerSecret = 'cs_a49b903ddc7972646359f360d79343cd1e33b6f8';
  static const productsUrl = 'https://spiritwebs.com/wp-json/wc/v3/products';
}

// ---------------- FIREBASE BACKGROUND HANDLER ----------------

// `vm:entry-point` is required so this top-level function isn't stripped
// out by tree-shaking in release builds — without it, background push
// notifications can silently stop working in release mode.
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  debugPrint('Background message received: ${message.messageId}');
}

// Thay thế hàm openChatFromNotification cũ bằng cặp hàm này:

Future<void> _openChatFromData(Map<String, dynamic> data) async {
  try {
    final senderId = int.tryParse(data['sender_id'] ?? '0') ?? 0;
    final senderName = data['sender_username'] ?? 'Người dùng';

    final me = await fetchMe();
    if (me == null) return;

    final myId = int.tryParse(me['id'].toString()) ?? 0;
    final myUsername = me['username'] ?? '';

    navigatorKey.currentState?.push(
      MaterialPageRoute(
        builder: (_) => ChatPage(
          userId: myId,
          username: myUsername,
          targetId: senderId,
          targetUser: senderName,
        ),
      ),
    );
  } catch (e) {
    debugPrint("Open chat error: $e");
  }
}

// Giữ nguyên chỗ gọi từ FCM (onMessageOpenedApp vẫn dùng hàm này)
Future<void> openChatFromNotification(RemoteMessage message) =>
    _openChatFromData(message.data);

// Hàm mới dùng cho NotificationPage (data thuần, không có RemoteMessage)
Future<void> openChatFromData(Map<String, dynamic> data) =>
    _openChatFromData(data);
// ---------------- ENTRY POINT ----------------

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  await setupFirebaseMessaging();

  runApp(const CryptoApp(initialPage: SplashPage()));
}

// ---------------- API HELPERS ----------------

Future<Map<String, dynamic>?> fetchMe() async {
  try {
    final token = await StorageHelper.read("jwt_token");

    final res = await http.get(
      Uri.parse("https://spiritwebs.com/wp-json/spiritwebs/v1/me"),
      headers: {"Authorization": "Bearer $token"},
    );

    if (res.statusCode != 200) return null;
    return jsonDecode(res.body) as Map<String, dynamic>;
  } catch (e) {
    debugPrint("fetchMe error: $e");
    return null;
  }
}

Future<Map<String, dynamic>?> _fetchProductById(String productId) async {
  try {
    final uri = Uri.parse(
      "${WooCommerceConfig.productsUrl}/$productId"
          "?consumer_key=${WooCommerceConfig.consumerKey}"
          "&consumer_secret=${WooCommerceConfig.consumerSecret}",
    );

    final res = await http.get(uri);
    if (res.statusCode != 200) return null;

    return jsonDecode(res.body) as Map<String, dynamic>;
  } catch (e) {
    debugPrint("Fetch product error: $e");
    return null;
  }
}

/// Single shared implementation for "open product/invite detail page by id",
/// used both when tapping a push notification and when resuming a pending
/// deep link. (Previously duplicated as two identical functions.)
Future<void> _navigateToInvite(String keoId) async {
  final product = await _fetchProductById(keoId);
  if (product == null) return;

  navigatorKey.currentState?.push(
    MaterialPageRoute(builder: (_) => ProductDetailPage(product: product)),
  );
}

Future<void> openInviteFromNotification(RemoteMessage message) async {
  final keoId = message.data['keo_id'];
  if (keoId == null) return;
  await _navigateToInvite(keoId);
}

Future<void> openInviteById(String keoId) => _navigateToInvite(keoId);

/*Future<void> openChatFromNotification(RemoteMessage message) async {
  try {
    final senderId = int.tryParse(message.data['sender_id'] ?? '0') ?? 0;
    final senderName = message.data['sender_username'] ?? 'Người dùng';

    final me = await fetchMe();
    if (me == null) return;

    final myId = int.tryParse(me['id'].toString()) ?? 0;
    final myUsername = me['username'] ?? '';

    navigatorKey.currentState?.push(
      MaterialPageRoute(
        builder: (_) => ChatPage(
          userId: myId,
          username: myUsername,
          targetId: senderId,
          targetUser: senderName,
        ),
      ),
    );
  } catch (e) {
    debugPrint("Open chat error: $e");
  }
}*/

// ---------------- IN-APP NOTIFICATION BANNER ----------------

void showAppNotification({required String title, required String body}) {
  final overlay = navigatorKey.currentState?.overlay;
  if (overlay == null) return;

  // Cancel any pending auto-dismiss timer from a previous banner, otherwise
  // it would fire later and remove *this* (newer) banner early.
  _notificationDismissTimer?.cancel();
  _appNotificationOverlay?.remove();

  _appNotificationOverlay = OverlayEntry(
    builder: (context) {
      return Positioned(
        top: 60,
        left: 16,
        right: 16,
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF1E3A8A).withOpacity(0.95),
                  const Color(0xFFFF7F50).withOpacity(0.85),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.25),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      const Icon(Icons.notifications_active,
                          color: Colors.white, size: 22),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              body,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    },
  );

  overlay.insert(_appNotificationOverlay!);

  _notificationDismissTimer = Timer(const Duration(seconds: 3), () {
    _appNotificationOverlay?.remove();
    _appNotificationOverlay = null;
  });
}

// ---------------- FIREBASE MESSAGING SETUP ----------------

Future<void> setupFirebaseMessaging() async {
  final messaging = FirebaseMessaging.instance;

  final settings = await messaging.requestPermission(
    alert: true,
    badge: true,
    sound: true,
  );
  debugPrint('User granted permission: ${settings.authorizationStatus}');

  final token = await messaging.getToken();
  debugPrint("Firebase Messaging Token: $token");

  await messaging.subscribeToTopic("all_devices");

  FirebaseMessaging.onMessage.listen((message) {
    final title = message.notification?.title ?? "Thông báo";
    final body = message.notification?.body ?? "";

    NotificationStore.add(
      title: title,
      body: body,
      type: message.data['type'],
      data: message.data,
    );

    unreadNotiVN.value++;
    showAppNotification(title: title, body: body);
  });

  FirebaseMessaging.onMessageOpenedApp.listen((message) {
    debugPrint('Clicked: ${message.notification?.title}');

    final type = message.data['type'];
    if (type == 'invite_keo') {
      openInviteFromNotification(message);
    } else if (type == 'chat_message') {
      openChatFromNotification(message);
    }
  });

  final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
  if (initialMessage != null) {
    final type = initialMessage.data['type'];

    if (type == 'invite_keo') {
      pendingKeoId = initialMessage.data['keo_id'];
    } else if (type == 'chat_message') {
      Future.delayed(
        const Duration(seconds: 1),
            () => openChatFromNotification(initialMessage),
      );
    }
  }
}

// ---------------- APP ROOT ----------------

class CryptoApp extends StatelessWidget {
  final Widget initialPage;
  const CryptoApp({super.key, required this.initialPage});

  @override
  Widget build(BuildContext context) {
    return AppLifecycleTracker(
      onStateChanged: (state) {
        debugPrint("🔥 APP STATE => $state");
        // TODO: gửi socket ở đây nếu muốn (sendAppStateToServer(state)).
      },
      child: MaterialApp(
        navigatorKey: navigatorKey,
        title: 'Crypto App',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.deepPurple,
          scaffoldBackgroundColor: Colors.grey[100],
        ),
        home: initialPage,
      ),
    );
  }
}

// ---------------- MAIN PAGE ----------------

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  Map<String, dynamic> _userData = {"slug": "Khách", "email": ""};
  int _userId = 0;
  bool _loading = true;

  // Each tab is built lazily the first time it's visited, then cached here.
  // - Index 0 (tab mặc định) được build ngay sau khi load xong user data.
  // - Các tab khác (Bản đồ, Nhóm, ...) chỉ build khi người dùng bấm vào lần
  //   đầu — tránh việc MapPage/GroupPage load tài nguyên (GPS, network...)
  //   ngay từ lúc mở app dù chưa ai xem tới.
  // - Sau khi đã build 1 lần, widget được giữ lại để khi quay lại tab đó,
  //   state cũ (vị trí cuộn, vị trí bản đồ...) không bị mất.
  //final List<Widget?> _pageCache = List<Widget?>.filled(5, null);
  final List<Widget?> _pageCache = List<Widget?>.filled(4, null);
  late final AnimationController _fabController;
  late final Animation<double> _fabAnimation;

  final Color primaryBlue = const Color(0xFF1E3A8A);
  final Color accentOrange = const Color(0xFFFF7F50);

  @override
  void initState() {
    super.initState();

    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fabAnimation = Tween<double>(begin: 1.0, end: 1.2).animate(
      CurvedAnimation(parent: _fabController, curve: Curves.easeInOut),
    );

    _bootstrap();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _openPendingInvite();
    });
  }

  @override
  void dispose() {
    _fabController.dispose();
    super.dispose();
  }

  /// Loads user data + user id once, then builds *only* the initially
  /// selected tab. Other tabs are built lazily in `_onItemTapped`.
  ///
  /// Wrapped in try/catch so that if reading from storage throws for any
  /// reason, we still fall back to defaults and clear `_loading` instead of
  /// leaving the user stuck on the spinner forever.
  Future<void> _bootstrap() async {
    Map<String, dynamic> userData = {"slug": "Khách", "email": ""};
    int userId = 0;

    try {
      final jsonString = await StorageHelper.read("user_data");
      final userIdString = await StorageHelper.read("user_id");

      if (jsonString != null && jsonString.isNotEmpty) {
        try {
          final decoded = jsonDecode(jsonString);
          if (decoded is Map<String, dynamic>) {
            userData = decoded;
          }
        } catch (e) {
          debugPrint("Lỗi parse user_data: $e");
        }
      }

      userId = int.tryParse(userIdString ?? '') ?? 0;
    } catch (e) {
      debugPrint("Lỗi đọc storage, dùng giá trị mặc định: $e");
    }

    if (!mounted) return;
    setState(() {
      _userData = userData;
      _userId = userId;
      _loading = false;
      // Chỉ build tab đang được chọn (mặc định là tab 0), không build
      // trước các tab khác.
      _pageCache[_selectedIndex] = _pageFor(_selectedIndex);
    });
  }

  /// Tạo widget thật cho 1 tab, dùng `_userData`/`_userId` đã load.
  Widget _pageFor(int index) {
    switch (index) {
      case 0:
        return const ShopPage();
      case 1:
        return MapPage(
          userId: _userId,
          username: _userData['display_name'] ?? _userData['slug'] ?? 'Khách',
          email: _userData['email'] ?? '',
        );
      case 2:
        return const GroupPage();      // trước là case 3
      case 3:
        return const ProfilePage();    // trước là case 4
      default:
        return const SizedBox.shrink();
    }
  }

  Future<void> _openPendingInvite() async {
    if (pendingKeoId == null) return;

    final id = pendingKeoId!;
    pendingKeoId = null;

    await Future.delayed(const Duration(milliseconds: 500));
    openInviteById(id);
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;

      // Build tab này nếu đây là lần đầu người dùng bấm vào.
      _pageCache[index] ??= _pageFor(index);

      // Tab "Thông báo"
      /*if (index == 2) {
        unreadNotiVN.value = 0;
      }*/
    });
  }

  Widget _navItem(IconData icon, String label, int index) {
    final isSelected = _selectedIndex == index;

    return GestureDetector(
      onTap: () => _onItemTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: isSelected ? accentOrange : Colors.grey[700],
          ),
          // ĐÃ XÓA toàn bộ Stack + ValueListenableBuilder badge
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: isSelected ? accentOrange : Colors.grey[700],
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              primaryBlue.withOpacity(0.1),
              accentOrange.withOpacity(0.05),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: _loading
            ? const Center(
          child: CircularProgressIndicator(color: Color(0xFFFF7F50)),
        )
            : IndexedStack(
          index: _selectedIndex,
          // Tab chưa từng được bấm vào sẽ hiện placeholder rỗng
          // (không tốn gì) thay vì build trước widget thật của nó.
          children: List<Widget>.generate(
            _pageCache.length,
                (i) => _pageCache[i] ?? const SizedBox.shrink(),
          ),
        ),
      ),
      floatingActionButton: MouseRegion(
        onEnter: (_) => _fabController.forward(),
        onExit: (_) => _fabController.reverse(),
        child: AnimatedBuilder(
          animation: _fabAnimation,
          builder: (context, child) => Transform.scale(
            scale: _fabAnimation.value,
            child: FloatingActionButton(
              backgroundColor: accentOrange,
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CreateInvitePage()),
                );
              },
              child: const Icon(Icons.add, size: 36, color: Colors.white),
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        color: Colors.transparent,
        elevation: 0,
        shape: const CircularNotchedRectangle(),
        notchMargin: 8,
        child: Container(
          height: 60,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                primaryBlue.withOpacity(0.2),
                accentOrange.withOpacity(0.1),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _navItem(Icons.group, "Lời mời", 0),
              _navItem(Icons.map_outlined, "Bản đồ", 1),
              const SizedBox(width: 40),
              // ĐÃ XÓA: _navItem(Icons.notifications, "Thông báo", 2),
              _navItem(Icons.article_outlined, "Quán", 2),       // trước index 3
              _navItem(Icons.account_circle_outlined, "Hồ sơ", 3), // trước index 4
            ],
          ),
        ),
      ),
    );
  }
}