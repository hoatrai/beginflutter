// =============================================================================
// product_detail_page.dart
// =============================================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart' as shimmer;
import 'package:video_compress/video_compress.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../helpers/storage_helper.dart';
import '../helpers/user_helper.dart';
import 'group_chat_page.dart';
import 'invite_map_page.dart';
import 'newsfeed_page.dart';
import 'spin_wheel.dart';
import '../config/app_config.dart';
import '../app_globals.dart';

// =============================================================================
// 🆕 Nhãn hoạt động theo thể loại (Nhậu/Karaoke/Bar-Pub/Beer Club) — dùng để
// thông báo "tham gia/rời ..." đọc đúng thể loại thay vì luôn cố định
// "bàn nhậu". Match theo "chứa" (giống hệt _getCategoryColor() bên
// shop_page.dart/invite_card_page.dart) vì category_names có thể là chuỗi
// gộp nhiều thể loại, vd "Nhậu, Karaoke".
// =============================================================================
String _getCategoryActivityLabel(String categoryText) {
  final lower = categoryText.toLowerCase();
  if (lower.contains('karaoke')) return 'buổi karaoke';
  if (lower.contains('beer')) return 'buổi beer club';
  if (lower.contains('bar') || lower.contains('pub')) return 'buổi bar/pub';
  if (lower.contains('nhậu')) return 'bàn nhậu';
  return 'bàn nhậu'; // fallback: giữ đúng hành vi cũ khi không xác định được thể loại
}

// =============================================================================
// CONSTANTS
// =============================================================================

abstract class _AppColors {
  static const primaryBlue   = Color(0xFF0D47A1);
  static const accentOrange  = Color(0xFFF57C00);
  static const surface       = Color(0x12FFFFFF);
  static const border        = Color(0x14FFFFFF);
}

abstract class _ApiUrls {
  static const base = '${AppConfig.webDomain}/wp-json/nhau/v1';
  static String inviteByProduct(int productId) =>
      '$base/invite/by-product?product_id=$productId';
  static String inviteDetail(int inviteId) =>
      '$base/invite/detail?invite_id=$inviteId';
  static String inviteMedia(int inviteId) =>
      '$base/invite/media?invite_id=$inviteId';
  static const inviteJoin        = '$base/invite/join';
  static const inviteLeave       = '$base/invite/leave';
  static const inviteClose       = '$base/invite/close';
  static const inviteOpen        = '$base/invite/open';
  static const inviteKick        = '$base/invite/kick';
  static const inviteMediaAdd    = '$base/invite/media/add';
  static const inviteMediaDelete = '$base/invite/media/delete';
  static const ratingTrust       = '$base/rating/trust';
  static const attendanceUpdate  = '$base/invite/update-attendance';
  static const imageUpload       = '${AppConfig.webDomain}/wp-json/nhau/v1/upload';
  static const profileUsers      = '${AppConfig.webDomain}/wp-json/profile/v1/users';
  static const spinWheel         = '${AppConfig.webDomain}/wp-json/spiritwebs/v1/spin';
  static const gameNeverHaveIEver = '$base/game/never-have-i-ever';
  static const gameTruthOrDare    = '$base/game/truth-or-dare';
  static const gameDiceRoll       = '$base/game/dice-roll';
  static const socketUrl         = AppConfig.websocketUrl;
  static const defaultAvatar     = '${AppConfig.webDomain}/media/2025/10/default-avatar.png';

  // 🆕 Upload video lên server riêng (giống create_invite_page) thay vì
  // Cloudinary — cùng endpoint REST WordPress + Application Password.
  static const videoUpload       = '${AppConfig.webDomain}/wp-json/nhau/v1/upload-video';
  static const wpUsername        = 'adminroot';
  static const wpAppPassword     = 'hWfZ33bkTXZGsuK18zFilY1D';
}

// =============================================================================
// DATA MODELS
// =============================================================================

enum AttendanceStatus { going, onTheWay, late, notGoing, undecided }

extension AttendanceStatusExt on AttendanceStatus {
  String get key {
    switch (this) {
      case AttendanceStatus.going:     return 'going';
      case AttendanceStatus.onTheWay:  return 'on_the_way';
      case AttendanceStatus.late:      return 'late';
      case AttendanceStatus.notGoing:  return 'not_going';
      case AttendanceStatus.undecided: return 'undecided';
    }
  }

  String get label {
    switch (this) {
      case AttendanceStatus.going:     return '🟢 Đã tới';
      case AttendanceStatus.onTheWay:  return '🟡 Đang tới';
      case AttendanceStatus.late:      return '🟠 Tới trễ';
      case AttendanceStatus.notGoing:  return '🔴 Không đi';
      case AttendanceStatus.undecided: return '⚪ Chưa xác nhận';
    }
  }

  String get shortLabel {
    switch (this) {
      case AttendanceStatus.going:     return 'Đã tới';
      case AttendanceStatus.onTheWay:  return 'Đang tới';
      case AttendanceStatus.late:      return 'Tới trễ';
      case AttendanceStatus.notGoing:  return 'Không đi';
      case AttendanceStatus.undecided: return 'Vừa join';
    }
  }

  Color get color {
    switch (this) {
      case AttendanceStatus.going:     return Colors.green;
      case AttendanceStatus.onTheWay:  return Colors.orange;
      case AttendanceStatus.late:      return Colors.deepOrange;
      case AttendanceStatus.notGoing:  return Colors.red;
      case AttendanceStatus.undecided: return Colors.blue;
    }
  }

  static AttendanceStatus fromKey(String? key) =>
      AttendanceStatus.values.firstWhere(
            (e) => e.key == key,
        orElse: () => AttendanceStatus.undecided,
      );
}

class Participant {
  final int userId;
  final String name;
  final String status;
  final String role;
  final AttendanceStatus attendanceStatus;
  final int trustScore;
  String? avatar;
  bool isRated;
  int? myRating;

  Participant({
    required this.userId,
    required this.name,
    required this.status,
    required this.role,
    required this.attendanceStatus,
    required this.trustScore,
    this.avatar,
    this.isRated = false,
    this.myRating,
  });

  factory Participant.fromMap(Map<String, dynamic> m) => Participant(
    userId:           int.tryParse(m['user_id']?.toString() ?? '') ?? 0,
    name:             (m['display_name'] ?? m['name'])?.toString() ?? '',
    status:           m['status']?.toString() ?? '',
    role:             m['role']?.toString() ?? '',
    attendanceStatus: AttendanceStatusExt.fromKey(m['attendance_status']?.toString()),
    trustScore:       int.tryParse(m['trust_score']?.toString() ?? '') ?? 50,
    // 🆕 invite/detail giờ trả sẵn avatar_url (JOIN thẳng ở backend), khỏi
    // phải chờ round-trip enrich riêng nữa — xem _fetchParticipants().
    avatar:           m['avatar_url']?.toString(),
    isRated:          m['is_rated'] == 1,
    myRating:         m['my_rating'] != null ? int.tryParse(m['my_rating'].toString()) : null,
  );

  Participant copyWith({
    AttendanceStatus? attendanceStatus,
    bool? isRated,
    int? myRating,
    String? avatar,
  }) =>
      Participant(
        userId:           userId,
        name:             name,
        status:           status,
        role:             role,
        attendanceStatus: attendanceStatus ?? this.attendanceStatus,
        trustScore:       trustScore,
        avatar:           avatar ?? this.avatar,
        isRated:          isRated ?? this.isRated,
        myRating:         myRating ?? this.myRating,
      );
}

class MediaItem {
  final int id;
  final String url;
  final String type;
  final int? userId;

  const MediaItem({
    required this.id,
    required this.url,
    required this.type,
    this.userId,
  });

  bool get isVideo => type == 'video' || url.toLowerCase().contains('.mp4');

  factory MediaItem.fromMap(Map<String, dynamic> m) => MediaItem(
    id:     int.tryParse(m['id']?.toString() ?? '') ?? 0,
    url:    m['url']?.toString() ?? '',
    type:   m['type']?.toString() ?? 'image',
    userId: int.tryParse(m['user_id']?.toString() ?? ''),
  );
}

// 🆕 Media đang được chọn/nén/tải lên — hiển thị ngay (đẩy lên đầu danh sách)
// trước khi server trả URL thật, để user thấy phản hồi tức thì thay vì chờ.
class _PendingMedia {
  final File file;
  final String type; // 'image' | 'video'
  Uint8List? thumbnail;
  bool generatingThumb;
  double progress; // 0.0 - 1.0, chỉ dùng cho video
  bool uploading;
  bool error;

  _PendingMedia({
    required this.file,
    required this.type,
    this.thumbnail,
    this.generatingThumb = false,
    this.progress = 0.0,
    this.uploading = true,
    this.error = false,
  });
}

// =============================================================================
// WIDGET CHÍNH
// =============================================================================

class ProductDetailPage extends StatefulWidget {
  final Map<String, dynamic> product;
  final void Function(Map<String, dynamic> updatedProduct)? onJoin;
  // 🆕 Báo ngược ra trang danh sách (ShopPage) ngay khi 1 ảnh/video "khoảnh
  // khắc bàn nhậu" upload thành công, để card ngoài list cập nhật tức thì
  // mà không cần load lại toàn bộ danh sách sản phẩm.
  final void Function(String url, String type)? onMediaAdded;

  const ProductDetailPage({
    super.key,
    required this.product,
    this.onJoin,
    this.onMediaAdded,
  });

  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage>
    with SingleTickerProviderStateMixin {
  // ── State ──────────────────────────────────────────────────────────────────
  int _currentMediaIndex = 0;
  List<Participant> _participants = [];
  List<MediaItem> _inviteMedia = [];
  final List<_PendingMedia> _pendingMedia = []; // 🆕 upload đang chạy, hiển thị optimistic

  // 🆕 Cache thumbnail cho video ĐÃ được server confirm (trong _inviteMedia).
  // Key theo item.id — mỗi video có id riêng nên video thêm SAU không bao
  // giờ vô tình hiện lại ảnh thumbnail của video thêm TRƯỚC.
  final Map<int, Uint8List?> _confirmedVideoThumbCache = {};

  bool _isLoadingJoin          = false;
  bool _isUploadingMedia       = false;
  bool _isUpdatingAttendance   = false;
  bool _isUpdatingInviteStatus = false;
  // 🆕 Bật/tắt hiệu ứng pháo hoa khi check-in "Đã tới" thành công.
  bool _showCheckinFirework    = false;
  // 🔧 FIX: theo dõi danh sách URL video đã init lần gần nhất, thay cho cờ
  // boolean cũ chỉ cho phép init MỘT LẦN trong suốt vòng đời State.
  List<String> _initedVideoUrls = [];

  bool isJoined    = false;
  bool isHost      = false;
  bool isFull      = false;
  bool allowRating = false;

  int? _currentUserId;
  String? _currentUserName;
  int? inviteId;
  int joinedCount = 0;
  int maxPeople   = 0;
  int viewerCount = 0;

  String? inviteStatus;

  // 🆕 Nhãn hoạt động theo thể loại của kèo này (vd "buổi karaoke",
  // "bàn nhậu"...) — tính 1 lần từ widget.product, dùng chung cho mọi
  // thông báo tham gia/rời/kick trong _showInviteNotification().
  String get _activityLabel {
    final cats = widget.product['categories'] as List<dynamic>? ?? [];
    final catNames = cats
        .map((c) => (c as Map<String, dynamic>)['name']?.toString() ?? '')
        .where((n) => n.isNotEmpty)
        .join(', ');
    // Một số nơi (vd sau khi tạo/join lại) chỉ có sẵn 'category_names'
    // (chuỗi) thay vì 'categories' (list) — dùng luôn nếu 'categories' rỗng.
    final fallback = catNames.isEmpty
        ? (widget.product['category_names']?.toString() ?? '')
        : catNames;
    return _getCategoryActivityLabel(fallback);
  }

  // ── 🆕 TRẠNG THÁI "ĐANG DIỄN RA" ─────────────────────────────────────────
  // Cùng logic parse + ngưỡng với isLive/isSoon bên shop_page.dart (card
  // ngoài list), để badge "🔥 Đang diễn ra" ở card và trang chi tiết luôn
  // đồng bộ — tránh trường hợp card báo live nhưng bấm vào detail lại thấy
  // giao diện y hệt lúc chưa diễn ra.
  //
  // Backend hiện KHÔNG có field "giờ kết thúc" riêng cho invite (chỉ có
  // giờ bắt đầu ở meta 'time') nên "đang diễn ra" được suy ra là: đã qua
  // giờ bắt đầu nhưng chưa quá 24h — không có đếm ngược chính xác tới giờ
  // hết hạn thật, vì dữ liệu đó chưa tồn tại ở phía server cho invite.
  bool get _isLive {
    final metaData = widget.product['meta_data'] as List<dynamic>? ?? [];
    String? timeStr;
    for (final item in metaData) {
      if (item['key'] == 'time') {
        timeStr = item['value']?.toString();
        break;
      }
    }
    if (timeStr == null || timeStr.isEmpty) return false;
    try {
      final eventTime = DateFormat("dd/MM/yyyy HH:mm").parse(timeStr);
      final diff = eventTime.difference(DateTime.now());
      return diff.isNegative && diff.abs().inHours < 24;
    } catch (_) {
      return false;
    }
  }

  // Số người ĐÃ THỰC SỰ CÓ MẶT (check-in "Đã tới"), khác với joinedCount
  // (chỉ là số người đã đăng ký/join phòng) — quan trọng hơn nhiều khi
  // đang diễn ra vì cho biết ai thật sự đang ở bàn.
  int get _goingCount =>
      _participants.where((p) => p.attendanceStatus == AttendanceStatus.going).length;

  // Chính người dùng hiện tại đã check-in "Đã tới" chưa — dùng để quyết
  // định có cần đẩy nút check-in lên nổi bật hay không (đã tới rồi thì
  // khỏi cần giục nữa).
  bool get _hasCheckedIn => _participants.any(
        (p) => p.userId == _currentUserId && p.attendanceStatus == AttendanceStatus.going,
  );

  // Khuya (22h - 5h) VÀ đang diễn ra -> nhắc nhở an toàn nhẹ nhàng.
  bool get _isLateNight {
    final h = DateTime.now().hour;
    return h >= 22 || h < 5;
  }

  // ── Video ──────────────────────────────────────────────────────────────────
  // key = index in the carousel mediaList
  final Map<int, VideoPlayerController> _videoMap = {};
  Map<String, dynamic> _spinResult = {};
  bool _isSpinningApi = false; // chặn bấm "Quay ngay" nhiều lần khi đang chờ API

  // ── Story-style carousel controller ─────────────────────────────────────────
  final StoryProgressController _storyController = StoryProgressController();

  // 🆕 Vuốt xuống trên carousel để đóng cả trang (không chỉ mỗi carousel).
  // Gesture được bắt bên trong DoubleTapReaction (bọc carousel), nhưng
  // hiệu ứng kéo (translate/scale/fade) áp dụng cho TOÀN BỘ Scaffold ở đây.
  double _dismissDrag = 0;
  bool _isDismissDragging = false;

  void _onCarouselDragUpdate(double dy) {
    setState(() {
      _isDismissDragging = true;
      _dismissDrag = dy;
    });
  }

  void _onCarouselDragEnd(double dy, double velocity) {
    const closeDistance = 90.0; // kéo xuống > 90px là đóng trang
    const closeVelocity = 700.0; // hoặc vẩy nhanh xuống dưới
    if (dy > closeDistance || velocity > closeVelocity) {
      Navigator.maybePop(context);
      return;
    }
    // Kéo chưa đủ -> cả trang lò xo trả về vị trí gốc
    setState(() {
      _isDismissDragging = false;
      _dismissDrag = 0;
    });
  }

  // ── WebSocket ──────────────────────────────────────────────────────────────
  late WebSocketChannel _channel;
  Timer? _heartbeatTimer;
  bool _socketJoined = false;

  // ── Animation (join button pulse) ──────────────────────────────────────────
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // ── Carousel page controller ───────────────────────────────────────────────
  final PageController _pageController = PageController();

  bool get canJoin => inviteStatus == 'open' && !isFull;

  // ==========================================================================
  // LIFECYCLE
  // ==========================================================================

  @override
  void initState() {
    super.initState();
    _initAnimation();
    _connectSocket();
    _loadUserId();
    _loadJoinStatus();
    _initGameResultSound();
    _initTts();
  }

  // 🔊 âm thanh "tèn ten" phát khi CÓ KẾT QUẢ ở bất kỳ trò nào trong số:
  // Chưa Từng / Thật Hay Thách / Xúc Xắc Phạt — dùng chung 1 player vì cả
  // 3 trò đều đi qua hàm _runGameFlow() bên dưới, chỉ cần gắn 1 chỗ.
  final AudioPlayer _gameResultPlayer =
  AudioPlayer(playerId: 'game_result_sound');
  bool _gameResultSoundReady = false;

  // 🔊 TTS: đọc to nội dung câu "thật/thách", "chưa từng", "xúc xắc phạt"...
  // ngay khi kết quả hiện ra, để mọi người quanh bàn nghe được mà không cần
  // cúi xuống đọc màn hình.
  final FlutterTts _tts = FlutterTts();
  bool _ttsReady = false;

  Future<void> _initTts() async {
    // 🔍 Không được để _ttsReady kẹt ở false mãi mãi nếu lệnh native bị
    // treo (ví dụ máy không có engine TTS nào) — mọi lời gọi xuống platform
    // đều bọc timeout, và dù có gì xảy ra, cuối cùng vẫn set _ttsReady=true
    // để _speak() ít nhất CÓ THỬ gọi speak() (nó sẽ tự im lặng nếu máy
    // thật sự không có engine, thay vì code phía Dart tự chặn trước).
    try {
      // 🔍 Liệt kê engine TTS máy đang cài — nếu danh sách rỗng, máy/emulator
      // này không có bất kỳ engine đọc giọng nào, TTS sẽ luôn câm bất kể
      // code viết đúng hay sai.
      final engines = await _tts.getEngines.timeout(
        const Duration(seconds: 5),
        onTimeout: () {
          debugPrint('[TTS] ⏱️ getEngines() timeout — có thể máy không có engine TTS nào');
          return [];
        },
      );
      debugPrint('[TTS] Engines tìm thấy: $engines');

      final available = await _tts.isLanguageAvailable('vi-VN').timeout(
        const Duration(seconds: 5),
        onTimeout: () {
          debugPrint('[TTS] ⏱️ isLanguageAvailable() timeout');
          return false;
        },
      );
      debugPrint('[TTS] vi-VN available = $available');

      final langResult = await _tts.setLanguage('vi-VN').timeout(
        const Duration(seconds: 5),
        onTimeout: () {
          debugPrint('[TTS] ⏱️ setLanguage() timeout');
          return null;
        },
      );
      debugPrint('[TTS] setLanguage(vi-VN) -> $langResult');

      await _tts.setSpeechRate(0.48);
      await _tts.setPitch(1.0);
      await _tts.setVolume(1.0);

      _tts.setStartHandler(() => debugPrint('[TTS] ▶️ bắt đầu đọc'));
      _tts.setCompletionHandler(() => debugPrint('[TTS] ✅ đọc xong'));
      _tts.setCancelHandler(() => debugPrint('[TTS] ⏹️ bị huỷ'));
      _tts.setErrorHandler((msg) => debugPrint('[TTS] ❌ lỗi engine: $msg'));

      debugPrint('[TTS] ✅ init xong, sẵn sàng đọc');
    } catch (e) {
      debugPrint('[TTS] ❌ init lỗi: $e');
    } finally {
      // Luôn mở cờ ready dù bước cấu hình ngôn ngữ ở trên có trục trặc gì,
      // để không tự chặn speak() một cách vô lý.
      _ttsReady = true;
    }
  }

  /// Đọc to [text]. Nếu đang đọc dở câu trước thì dừng lại rồi đọc câu mới,
  /// tránh 2 câu chồng lên nhau khi user bấm liên tiếp.
  Future<void> _speak(String text) async {
    debugPrint('[TTS] 🔔 gọi _speak (ready=$_ttsReady): "$text"');
    if (!_ttsReady || text.trim().isEmpty) return;
    try {
      await _tts.stop();
      final result = await _tts.speak(text);
      debugPrint('[TTS] speak() trả về: $result');
    } catch (e) {
      debugPrint('[TTS] ❌ speak lỗi: $e');
    }
  }

  void _initGameResultSound() {
    _gameResultPlayer.setReleaseMode(ReleaseMode.stop);
    _gameResultPlayer.setVolume(1.0);
    _gameResultPlayer
        .setSource(AssetSource('sounds/win.wav'))
        .then((_) {
      _gameResultSoundReady = true;
      debugPrint('[GameResultSound] ✅ đã load win.wav thành công');
    })
        .catchError((e) {
      _gameResultSoundReady = false;
      debugPrint('[GameResultSound] ❌ LOAD win.wav THẤT BẠI: $e');
    });
  }

  void _playGameResultSound() {
    debugPrint('[GameResultSound] 🔔 gọi phát tiếng (ready=$_gameResultSoundReady)');
    if (!_gameResultSoundReady) return;
    _gameResultPlayer.seek(Duration.zero);
    _gameResultPlayer.resume().catchError((e) {
      debugPrint('[GameResultSound] ❌ resume() lỗi: $e');
    });
  }

  void _initAnimation() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.06).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    if (currentInviteId == inviteId) {
      isInviteDetailOpen = false;
      currentInviteId = null;
    }
    _heartbeatTimer?.cancel();
    _channel.sink.close();
    _pulseController.dispose();
    _pageController.dispose();
    _gameResultPlayer.dispose();
    _tts.stop();
    for (final c in _videoMap.values) c.dispose();
    _videoMap.clear();
    VideoCompress.deleteAllCache();
    super.dispose();
  }

  // ==========================================================================
  // VIDEO — initialise & control
  // ==========================================================================

  /// Khởi tạo lại toàn bộ video của carousel.
  /// 🔧 FIX: trước đây hàm này chỉ được gọi MỘT LẦN nhờ cờ `_videoInited`,
  /// nên nếu sản phẩm được sửa sau đó (danh sách video/ảnh trong
  /// `widget.product` thay đổi — ví dụ user edit lại bài đăng) thì carousel
  /// vẫn tiếp tục phát video CŨ vì `_videoMap` không được dispose/tạo lại.
  /// Giờ hàm này được gọi lại bất cứ khi nào danh sách URL video thực sự
  /// đổi (xem chỗ gọi trong `build()`), và luôn dispose sạch controller cũ
  /// trước khi tạo controller mới để không bị lẫn video của lần load trước.
  void _initVideos(List<Map<String, dynamic>> mediaList) {
    for (final c in _videoMap.values) {
      c.dispose();
    }
    _videoMap.clear();

    for (int i = 0; i < mediaList.length; i++) {
      final item = mediaList[i];
      if (item['type'] != 'video') continue;

      final ctrl =
      VideoPlayerController.networkUrl(Uri.parse(item['url'] as String));
      _videoMap[i] = ctrl;

      ctrl.initialize().then((_) {
        if (!mounted) return;
        ctrl.setLooping(true);
        ctrl.setVolume(1.0);
        // Auto-play only the first video
        if (i == 0 && _currentMediaIndex == 0) ctrl.play();
        setState(() {});
      });
    }
  }

  /// When the carousel page changes: pause all except the active one.
  void _onPageChanged(int index) {
    setState(() => _currentMediaIndex = index);
    _videoMap.forEach((i, ctrl) {
      if (!ctrl.value.isInitialized) return;
      if (i == index) {
        ctrl.play();
      } else {
        ctrl.pause();
        ctrl.seekTo(Duration.zero);
      }
    });
  }

  // ==========================================================================
  // WEBSOCKET
  // ==========================================================================

  void _connectSocket() {
    _channel = WebSocketChannel.connect(Uri.parse(_ApiUrls.socketUrl));
    _channel.sink.add(jsonEncode({
      'topic': 'phoenix',
      'event': 'phx_join',
      'payload': {},
      'ref': '1',
    }));
    _channel.stream.listen(_handleSocketMessage, onError: (e) {
      debugPrint('❌ Socket error: $e');
    });
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _channel.sink.add(jsonEncode({
        'topic': 'phoenix',
        'event': 'heartbeat',
        'payload': {},
        'ref': _nowRef(),
      }));
    });
  }

  Future<void> _handleSocketMessage(dynamic message) async {
    try {
      final decoded = jsonDecode(message as String) as Map<String, dynamic>;
      final event   = decoded['event'] as String?;
      final payload = decoded['payload'] as Map<String, dynamic>? ?? {};

      if (event == 'phx_reply' &&
          decoded['topic'] == 'phoenix' &&
          !_socketJoined) {
        _socketJoined = true;
        if (inviteId != null) _joinInviteRoom(inviteId!);
        return;
      }

      if (event == 'viewer_count') {
        if (!mounted) return;
        setState(() => viewerCount = (payload['count'] as int?) ?? 0);
        return;
      }

      const reloadEvents = {
        'user_joined', 'user_left', 'user_kicked',
        'invite_closed', 'invite_opened', 'attendance_updated',
      };
      if (reloadEvents.contains(event) && payload['invite_id'] == inviteId) {
        await _fetchParticipants(inviteId!);
        if (mounted) _showInviteNotification(event!, payload);
      }
    } catch (e) {
      debugPrint('❌ Socket parse error: $e');
    }
  }

  Future<void> _joinInviteRoom(int id) async {
    final userId = await StorageHelper.read('user_id');
    _channel.sink.add(jsonEncode({
      'topic':    'invite:$id',
      'event':    'phx_join',
      'payload':  {'user_id': userId?.toString()},
      'ref':      _nowRef(),
      'join_ref': _nowRef(),
    }));
  }

  String _nowRef() => DateTime.now().millisecondsSinceEpoch.toString();

  /// Bắn một event lên topic "invite:$inviteId" để các client khác đang
  /// mở cùng invite này nhận được realtime (server sẽ broadcast_from!,
  /// nghĩa là chính máy mình sẽ KHÔNG nhận lại event của chính mình).
  void _pushInviteEvent(String event, Map<String, dynamic> payload) {
    if (inviteId == null) return;
    _channel.sink.add(jsonEncode({
      'topic':   'invite:$inviteId',
      'event':   event,
      'payload': {...payload, 'invite_id': inviteId},
      'ref':     _nowRef(),
    }));
  }

  /// Hiện snackbar thông báo khi nhận được event từ người khác trong nhóm.
  // 🔧 FIX: đọc đúng tên hoạt động theo thể loại của kèo (vd "buổi karaoke",
  // "buổi bar/pub", "buổi beer club") thay vì luôn cố định "bàn nhậu" —
  // dùng _activityLabel (tính từ categories của widget.product).
  // 🔧 FIX: fallback đọc cả 'username' (khoá do backend Phoenix cũ trả về)
  // lẫn 'user_name' (khoá client tự push), để không hiện "Ai đó" nếu 1 trong
  // 2 nguồn còn sót lại còn dùng khoá kia.
  void _showInviteNotification(String event, Map<String, dynamic> payload) {
    final name = payload['user_name']?.toString() ??
        payload['username']?.toString() ??
        'Ai đó';
    final activity = _activityLabel;
    String? msg;
    String? spokenText; // bản đọc to, không kèm emoji
    switch (event) {
      case 'user_joined':
        msg = '🙋 $name vừa tham gia $activity';
        spokenText = '$name vừa tham gia $activity';
        break;
      case 'user_left':
        msg = '🚪 $name đã rời $activity';
        spokenText = '$name đã rời $activity';
        break;
      case 'user_kicked':
        msg = '⛔ $name đã bị mời ra khỏi $activity';
        spokenText = '$name đã bị mời ra khỏi $activity';
        break;
      case 'invite_closed':
        msg = '🔒 Chủ phòng đã đóng $activity';
        spokenText = 'Chủ phòng đã đóng $activity';
        break;
      case 'invite_opened':
        msg = '🔓 Chủ phòng đã mở lại $activity';
        spokenText = 'Chủ phòng đã mở lại $activity';
        break;
      case 'attendance_updated':
        final status = AttendanceStatusExt.fromKey(payload['status']?.toString());
        msg = '📍 $name: ${status.label}';
        spokenText = '$name ${status.label}';
        break;
    }
    if (msg != null) _showSnack(msg);
    if (spokenText != null) _speak(spokenText);
  }

  // ==========================================================================
  // API — AUTH
  // ==========================================================================

  Future<Map<String, String>> _authHeaders() async {
    final token = await StorageHelper.read('jwt_token');
    return {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    };
  }

  // ==========================================================================
  // API — LOAD DATA
  // ==========================================================================

  Future<void> _loadUserId() async {
    final id = await StorageHelper.read('user_id');
    if (!mounted) return;
    setState(() {
      _currentUserId = id != null ? int.tryParse(id.toString()) : null;
    });
    try {
      final currentUser = await UserHelper.getCurrentUser();
      if (!mounted) return;
      setState(() {
        _currentUserName = (currentUser['username'] as String?) ?? 'Ai đó';
      });
    } catch (e) {
      debugPrint('⚠️ _loadUserId (username): $e');
    }
  }

  Future<void> _loadJoinStatus() async {
    if (!mounted) return;
    setState(() => _isLoadingJoin = true);
    try {
      final productId = int.parse(widget.product['id'].toString());
      final id = await _fetchInviteIdByProduct(productId);
      if (id != null && mounted) {
        setState(() => inviteId = id);
        isInviteDetailOpen = true;
        currentInviteId = id;
        if (_socketJoined) _joinInviteRoom(id);
        await Future.wait([_fetchInviteMedia(), _fetchParticipants(id)]);
      }
    } catch (e) {
      debugPrint('❌ _loadJoinStatus: $e');
    } finally {
      if (mounted) setState(() => _isLoadingJoin = false);
    }
  }

  Future<int?> _fetchInviteIdByProduct(int productId) async {
    try {
      final res = await http.get(
        Uri.parse(_ApiUrls.inviteByProduct(productId)),
        headers: await _authHeaders(),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        if (data['success'] == true) {
          return int.tryParse(data['invite_id'].toString());
        }
      }
    } catch (e) {
      debugPrint('❌ _fetchInviteIdByProduct: $e');
    }
    return null;
  }

  Future<void> _fetchParticipants(int id) async {
    try {
      final res = await http.get(
        Uri.parse(_ApiUrls.inviteDetail(id)),
        headers: await _authHeaders(),
      );
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] != true) return;

      final invite = data['invite'] as Map<String, dynamic>;
      final parsed = (data['members'] as List? ?? [])
          .map((m) => Participant.fromMap(m as Map<String, dynamic>))
          .toList();

      if (!mounted) return;

      setState(() {
        inviteId     = int.tryParse(invite['id'].toString()) ?? inviteId;
        isJoined     = data['is_joined'] ?? false;
        isHost       = data['is_host'] ?? false;
        isFull       = data['is_full'] ?? false;
        joinedCount  = int.tryParse(data['joined_count'].toString()) ?? 0;
        inviteStatus = invite['status']?.toString() ?? 'open';
        maxPeople    = int.tryParse(invite['max_people'].toString()) ?? 0;
        allowRating  = inviteStatus == 'closed';
        _participants = parsed;
      });

      widget.onJoin?.call({
        'id': widget.product['id'],
        'joined_count': joinedCount,
      });

      // 🆕 FIX PERFORMANCE: avatar giờ đã có sẵn trong `parsed` (backend
      // trả kèm avatar_url trong CÙNG request invite/detail ở trên), nên
      // participant card hiện NGAY, không còn phải đợi thêm 1 round-trip
      // riêng chỉ để tô avatar nữa.
      //
      // _enrichWithAvatars() giờ chỉ là lớp dự phòng — chạy KHÔNG chặn UI
      // (không await ở đây), và bên trong nó cũng chỉ hỏi cho những user
      // nào thật sự còn thiếu avatar_url (vd: server cũ chưa deploy bản
      // JOIN mới). Trường hợp bình thường (đã deploy đủ), danh sách rỗng
      // -> hàm return ngay, không tốn request nào.
      final missingAvatar = parsed.where((p) => (p.avatar ?? '').isEmpty).toList();
      if (missingAvatar.isNotEmpty) {
        _enrichWithAvatars(missingAvatar).then((_) {
          if (mounted) setState(() {});
        });
      }
    } catch (e) {
      debugPrint('❌ _fetchParticipants: $e');
    }
  }

  Future<void> _enrichWithAvatars(List<Participant> list) async {
    if (list.isEmpty) return;
    try {
      final res = await http.post(
        Uri.parse(_ApiUrls.profileUsers),
        headers: await _authHeaders(),
        body: jsonEncode({'ids': list.map((p) => p.userId).toList()}),
      );
      if (res.statusCode != 200) return;
      final data  = jsonDecode(res.body) as Map<String, dynamic>;
      final users = data['users'] as List? ?? [];
      final map   = <int, String>{
        for (final u in users.cast<Map<String, dynamic>>())
          (u['user_id'] as int): u['avatar_url']?.toString() ?? _ApiUrls.defaultAvatar,
      };
      for (final p in list) {
        p.avatar = map[p.userId] ?? _ApiUrls.defaultAvatar;
      }
    } catch (e) {
      debugPrint('⚠️ _enrichWithAvatars: $e');
    }
  }

  Future<void> _fetchInviteMedia() async {
    if (inviteId == null) return;
    try {
      final res  = await http.get(Uri.parse(_ApiUrls.inviteMedia(inviteId!)));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true && mounted) {
        setState(() {
          _inviteMedia = (data['items'] as List? ?? [])
              .map((m) => MediaItem.fromMap(m as Map<String, dynamic>))
              .toList();
        });
      }
    } catch (e) {
      debugPrint('❌ _fetchInviteMedia: $e');
    }
  }

  /// 🆕 Sinh thumbnail thật cho video đã upload xong (server confirm), để
  /// mục "Khoảnh khắc bàn nhậu" hiện ảnh thay vì chỉ ô đen + icon play.
  /// Cache theo `item.id` — KHÔNG dùng biến/field dùng chung — nên video
  /// được thêm sau luôn hiện đúng ảnh của chính nó, không bị lẫn với ảnh
  /// của video thêm trước đó.
  Future<Uint8List?> _getConfirmedVideoThumb(MediaItem item) async {
    if (_confirmedVideoThumbCache.containsKey(item.id)) {
      return _confirmedVideoThumbCache[item.id];
    }
    try {
      final thumb = await VideoThumbnail.thumbnailData(
        video: item.url,
        imageFormat: ImageFormat.JPEG,
        maxWidth: 200,
        quality: 40,
      );
      _confirmedVideoThumbCache[item.id] = thumb;
      return thumb;
    } catch (e) {
      debugPrint('⚠️ _getConfirmedVideoThumb: $e');
      _confirmedVideoThumbCache[item.id] = null;
      return null;
    }
  }

  // ==========================================================================
  // API — ACTIONS
  // ==========================================================================

  Future<void> _joinInvite() async {
    if (!canJoin || inviteId == null) {
      _showSnack('Không thể tham gia kèo này');
      return;
    }
    setState(() => _isLoadingJoin = true);
    try {
      final res = await http.post(
        Uri.parse(_ApiUrls.inviteJoin),
        headers: await _authHeaders(),
        body: jsonEncode({'invite_id': inviteId}),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] != true) throw Exception(data['message']);
      await _fetchParticipants(inviteId!);
      _pushInviteEvent('user_joined', {'user_name': _currentUserName});
      _showSnack('Bạn đã tham gia thành công! 🎉');
    } catch (e) {
      _showSnack('Không thể tham gia: $e');
    } finally {
      if (mounted) setState(() => _isLoadingJoin = false);
    }
  }

  Future<void> _leaveInvite() async {
    if (inviteId == null) return;

    // Chủ phòng không được rời
    if (isHost) {
      await showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0D47A1), Color(0xFF2D1B69)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 30),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: Colors.orangeAccent.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.lock_rounded,
                      color: Colors.orangeAccent, size: 30),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Chủ phòng không thể rời',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(
                  'Bạn là 👑 chủ phòng.\nHãy đóng bàn hoặc nhường quyền cho thành viên khác trước khi rời.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.65),
                      fontSize: 13,
                      height: 1.6),
                ),
                const SizedBox(height: 22),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.15)),
                    ),
                    child: const Text(
                      'Đã hiểu',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
      return;
    }

    setState(() => _isLoadingJoin = true);
    try {
      final res = await http.post(
        Uri.parse(_ApiUrls.inviteLeave),
        headers: await _authHeaders(),
        body: jsonEncode({'invite_id': inviteId}),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] != true) throw Exception(data['message']);
      await _fetchParticipants(inviteId!);
      _pushInviteEvent('user_left', {'user_name': _currentUserName});
      _showSnack('Đã rời phòng');
    } catch (e) {
      _showSnack('Không thể rời phòng: $e');
    } finally {
      if (mounted) setState(() => _isLoadingJoin = false);
    }
  }

  Future<void> _kickUser(int targetUserId) async {
    if (inviteId == null) return;
    final target = _participants.firstWhere(
          (p) => p.userId == targetUserId,
      orElse: () => Participant(
        userId: 0, name: 'Thành viên', status: '', role: '',
        attendanceStatus: AttendanceStatus.undecided,
        trustScore: 50,
      ),
    );
    try {
      final res = await http.post(
        Uri.parse(_ApiUrls.inviteKick),
        headers: await _authHeaders(),
        body: jsonEncode({'invite_id': inviteId, 'user_id': targetUserId}),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] != true) throw Exception(data['message']);
      await _fetchParticipants(inviteId!);
      _pushInviteEvent('user_kicked', {
        'user_name': target.name,
        'target_user_id': targetUserId,
      });
      _showSnack('Đã kick thành viên');
    } catch (e) {
      _showSnack('Không thể kick: $e');
    }
  }

  Future<void> _toggleInviteStatus() async {
    if (inviteId == null) return;
    setState(() => _isUpdatingInviteStatus = true);
    try {
      final wasOpen = inviteStatus == 'open';
      final url = wasOpen ? _ApiUrls.inviteClose : _ApiUrls.inviteOpen;
      final res = await http.post(
        Uri.parse(url),
        headers: await _authHeaders(),
        body: jsonEncode({'invite_id': inviteId}),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) {
        await _fetchParticipants(inviteId!);
        _pushInviteEvent(wasOpen ? 'invite_closed' : 'invite_opened', {});
        _showSnack(wasOpen ? 'Đã đóng bàn' : 'Đã mở lại bàn');
      }
    } catch (e) {
      debugPrint('❌ _toggleInviteStatus: $e');
    } finally {
      if (mounted) setState(() => _isUpdatingInviteStatus = false);
    }
  }

  // 🆕 Bán kính cho phép check-in (mét) — đứng trong phạm vi này quanh toạ
  // độ kèo mới bấm "Đã tới" được, tránh check-in khống khi còn ở xa.
  static const double _checkinRadiusMeters = 300;

  Future<void> _checkinWithGps() async {
    double? venueLat;
    double? venueLng;

    final meta = widget.product['meta'];
    if (meta is Map) {
      venueLat = double.tryParse(meta['lat']?.toString() ?? '');
      venueLng = double.tryParse(meta['lng']?.toString() ?? '');
    }
    // 🆕 Fallback: một số nơi (vd "Kèo của tôi") trả 'meta_data' dạng
    // list [{key,value}] thay vì map 'meta' đã parse sẵn — quét thêm ở
    // đây để không báo nhầm "chưa có toạ độ" dù dữ liệu thật sự có.
    if (venueLat == null || venueLng == null) {
      final metaData = widget.product['meta_data'] as List<dynamic>? ?? [];
      for (final item in metaData) {
        if (item is Map && item['key'] == 'lat') {
          venueLat ??= double.tryParse(item['value']?.toString() ?? '');
        }
        if (item is Map && item['key'] == 'lng') {
          venueLng ??= double.tryParse(item['value']?.toString() ?? '');
        }
      }
    }

    if (venueLat == null || venueLng == null) {
      _showSnack('❌ Kèo này chưa có toạ độ địa điểm nên không xác thực GPS được, báo chủ bàn cập nhật lại vị trí giúp nhé');
      return;
    }

    setState(() => _isUpdatingAttendance = true);
    try {
      // ── Kiểm tra dịch vụ định vị + quyền truy cập, giống pattern đã
      // dùng ở shop_page/near_pub ──────────────────────────────────────
      if (!await Geolocator.isLocationServiceEnabled()) {
        _showSnack('❌ Bạn cần bật định vị (GPS) để check-in');
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        _showSnack('❌ Cần cấp quyền vị trí để check-in');
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      ).timeout(const Duration(seconds: 12));

      final distance = Geolocator.distanceBetween(
        pos.latitude, pos.longitude, venueLat, venueLng,
      );

      if (distance > _checkinRadiusMeters) {
        final distText = distance >= 1000
            ? '${(distance / 1000).toStringAsFixed(1)}km'
            : '${distance.toStringAsFixed(0)}m';
        _showSnack('❌ Bạn đang cách địa điểm ~$distText, cần tới gần hơn ($_checkinRadiusMeters m) mới check-in được');
        return;
      }

      // 🆕 Vẫn gửi lat/lng thật lên server để server tự verify lại (không
      // chỉ tin phép tính khoảng cách phía client) — chốt bảo mật thật
      // nằm ở nhau_update_attendance_status() bên PHP.
      await _updateAttendance(AttendanceStatus.going, lat: pos.latitude, lng: pos.longitude);

      // 🆕 _updateAttendance() chỉ set attendanceStatus = going trong
      // setState khi server trả success -> _hasCheckedIn đúng nghĩa là
      // "vừa check-in thành công", nên dùng nó để quyết định có bắn pháo
      // hoa hay không (không bắn nếu API lỗi/GPS bị chặn ở trên).
      if (_hasCheckedIn && mounted) {
        setState(() => _showCheckinFirework = true);
      }
    } catch (e) {
      _showSnack('❌ Không lấy được vị trí, thử lại: $e');
    } finally {
      if (mounted) setState(() => _isUpdatingAttendance = false);
    }
  }

  Future<void> _updateAttendance(AttendanceStatus status, {double? lat, double? lng}) async {
    if (inviteId == null) return;
    setState(() => _isUpdatingAttendance = true);
    try {
      final res = await http.post(
        Uri.parse(_ApiUrls.attendanceUpdate),
        headers: await _authHeaders(),
        body: jsonEncode({
          'invite_id': inviteId,
          'status': status.key,
          if (lat != null) 'lat': lat,
          if (lng != null) 'lng': lng,
        }),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) {
        setState(() {
          final idx = _participants.indexWhere((p) => p.userId == _currentUserId);
          if (idx != -1) {
            _participants[idx] =
                _participants[idx].copyWith(attendanceStatus: status);
          }
        });
        _pushInviteEvent('attendance_updated', {
          'user_name': _currentUserName,
          'status': status.key,
        });
        _showSnack('✅ Đã cập nhật trạng thái');
      } else {
        throw Exception(data['message']);
      }
    } catch (e) {
      _showSnack('❌ Lỗi cập nhật: $e');
    } finally {
      if (mounted) setState(() => _isUpdatingAttendance = false);
    }
  }

  Future<void> _rateUser(int userId, int point) async {
    try {
      final res = await http.post(
        Uri.parse(_ApiUrls.ratingTrust),
        headers: await _authHeaders(),
        body: jsonEncode(
            {'user_id': userId, 'point': point, 'invite_id': inviteId}),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) {
        setState(() {
          _participants = _participants.map((p) {
            if (p.userId == userId) return p.copyWith(isRated: true, myRating: point);
            return p;
          }).toList();
        });
        await _fetchParticipants(inviteId!);
      } else {
        _showSnack('❌ ${data['message'] ?? 'Đánh giá thất bại'}');
      }
    } catch (e) {
      debugPrint('❌ _rateUser: $e');
      _showSnack('❌ Lỗi kết nối, thử lại sau');
    }
  }

  // ==========================================================================
  // API — MEDIA UPLOAD
  // ==========================================================================

  Future<void> _pickAndUpload(String type) async {
    final picker = ImagePicker();
    final file = type == 'video'
        ? await picker.pickVideo(source: ImageSource.gallery)
        : await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file == null) return;

    // 🆕 Đẩy ngay item lên ĐẦU danh sách hiển thị (trước cả _inviteMedia đã
    // có) để user thấy media của mình xuất hiện tức thì, không cần đợi
    // upload + fetch lại từ server.
    final pending = _PendingMedia(
      file: File(file.path),
      type: type,
      generatingThumb: type == 'video',
    );
    setState(() => _pendingMedia.insert(0, pending));

    if (type == 'video') {
      final thumb = await VideoThumbnail.thumbnailData(
        video: pending.file.path,
        imageFormat: ImageFormat.JPEG,
        maxWidth: 200,
        quality: 25,
      );
      if (!mounted) return;
      setState(() {
        pending.thumbnail = thumb;
        pending.generatingThumb = false;
      });
    }

    await _uploadMedia(pending);
  }

  Future<void> _uploadMedia(_PendingMedia pending) async {
    final type = pending.type;
    setState(() => _isUploadingMedia = true);
    try {
      final headers = await _authHeaders();
      String mediaUrl;

      if (type == 'video') {
        // 🆕 Nén video trước khi upload để giảm tải server và tăng tốc độ
        // gửi. Nếu nén lỗi, fallback dùng file gốc để không chặn user.
        File fileToUpload = pending.file;
        try {
          final info = await VideoCompress.compressVideo(
            fileToUpload.path,
            quality: VideoQuality.MediumQuality,
            deleteOrigin: false,
            includeAudio: true,
          );
          if (info?.file != null) fileToUpload = info!.file!;
        } catch (_) {
          // nén thất bại -> vẫn upload file gốc
        }
        mediaUrl = await _uploadVideoToOwnServer(
          fileToUpload,
          onProgress: (p) {
            if (!mounted) return;
            setState(() => pending.progress = p);
          },
        );
      } else {
        final req =
        http.MultipartRequest('POST', Uri.parse(_ApiUrls.imageUpload))
          ..headers.addAll({'Authorization': headers['Authorization']!})
          ..files
              .add(await http.MultipartFile.fromPath('file', pending.file.path));
        final res  = await http.Response.fromStream(await req.send());
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        if (data['success'] != true) {
          throw Exception(data['message'] ?? 'Upload ảnh thất bại');
        }
        mediaUrl = data['url'] as String;
      }

      final res = await http.post(
        Uri.parse(_ApiUrls.inviteMediaAdd),
        headers: headers,
        body: jsonEncode(
            {'invite_id': inviteId, 'type': type, 'url': mediaUrl}),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] != true) {
        throw Exception(data['message'] ?? 'Không lưu được media');
      }
      await _fetchInviteMedia();
      // 🆕 Báo ngược ra ShopPage (nếu có) để card ngoài list hiện video/ảnh
      // mới này ngay, không cần đợi user quay lại rồi pull-to-refresh.
      widget.onMediaAdded?.call(mediaUrl, type);
      if (mounted) setState(() => _pendingMedia.remove(pending));
      _showSnack(type == 'video' ? '🎥 Video đã đăng' : '📸 Ảnh đã đăng');
    } catch (e) {
      if (!mounted) return;
      setState(() {
        pending.uploading = false;
        pending.error = true;
      });
      // 🆕 Hiện rõ lỗi thật ngay trên thumbnail (icon lỗi + nút xóa) thay vì
      // chỉ báo snack rồi làm item biến mất im lặng.
      _showSnack('❌ $e');
    } finally {
      if (mounted) {
        setState(() => _isUploadingMedia = _pendingMedia.any((p) => p.uploading));
      }
    }
  }

  // ─── UPLOAD VIDEO LÊN SERVER RIÊNG (thay cho Cloudinary) ────────────────────
  // Cùng endpoint/cách xác thực với create_invite_page: multipart tới REST
  // endpoint WordPress tự viết, xác thực bằng Application Password.
  Future<String> _uploadVideoToOwnServer(
      File videoFile, {
        void Function(double progress)? onProgress,
      }) async {
    final uri = Uri.parse(_ApiUrls.videoUpload);
    final credentials = base64Encode(
        utf8.encode('${_ApiUrls.wpUsername}:${_ApiUrls.wpAppPassword}'));

    final multipart = http.MultipartRequest('POST', uri);
    multipart.headers['Authorization'] = 'Basic $credentials';
    multipart.files.add(await http.MultipartFile.fromPath('file', videoFile.path));

    final totalBytes = multipart.contentLength;
    int bytesSent = 0;

    // Bọc byte stream gốc để đếm số byte đã gửi đi, từ đó tính % tiến trình
    final trackedStream = multipart.finalize().transform(
      StreamTransformer<List<int>, List<int>>.fromHandlers(
        handleData: (chunk, sink) {
          bytesSent += chunk.length;
          if (totalBytes > 0) onProgress?.call((bytesSent / totalBytes).clamp(0.0, 1.0));
          sink.add(chunk);
        },
      ),
    );

    // http.MultipartRequest không cho hook progress trực tiếp nên phải dựng
    // lại thành StreamedRequest với cùng headers/contentLength.
    final streamedRequest = http.StreamedRequest('POST', uri);
    streamedRequest.headers.addAll(multipart.headers);
    streamedRequest.contentLength = totalBytes;

    trackedStream.listen(
      streamedRequest.sink.add,
      onDone: () => streamedRequest.sink.close(),
      onError: (e, st) => streamedRequest.sink.addError(e, st),
      cancelOnError: true,
    );

    final response = await http.Client().send(streamedRequest);
    final resBody = await response.stream.bytesToString();

    if (response.statusCode == 200 || response.statusCode == 201) {
      final data = jsonDecode(resBody);
      final String? videoUrl = data['url'];
      if (videoUrl == null) throw Exception('Không nhận được URL video từ server');
      return videoUrl;
    }
    throw Exception('Upload video failed (${response.statusCode}): $resBody');
  }

  Future<void> _deleteMedia(int mediaId) async {
    try {
      final res = await http.post(
        Uri.parse(_ApiUrls.inviteMediaDelete),
        headers: await _authHeaders(),
        body: jsonEncode({'media_id': mediaId}),
      );
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) await _fetchInviteMedia();
    } catch (e) {
      debugPrint('❌ _deleteMedia: $e');
    }
  }

  // ==========================================================================
  // API — SPIN WHEEL
  // ==========================================================================

  Future<Map<String, dynamic>> _callSpinWheelApi() async {
    final res = await http.post(
      Uri.parse(_ApiUrls.spinWheel),
      headers: await _authHeaders(),
      body: jsonEncode({'invite_id': inviteId}),
    );
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (data['success'] != true) throw Exception(data['message'] ?? 'Spin failed');
    if (data['result'] == null) throw Exception('result = null từ server');
    return data;
  }

  // ==========================================================================
  // API — CÁC TRÒ CHƠI KHÁC (Chưa Từng / Thật Hay Thách / Xúc Xắc Phạt)
  // ==========================================================================

  Future<Map<String, dynamic>> _callGameApi(String url) async {
    final res = await http.post(
      Uri.parse(url),
      headers: await _authHeaders(),
      body: jsonEncode({'invite_id': inviteId}),
    );
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (data['success'] != true) throw Exception(data['message'] ?? 'Có lỗi xảy ra');
    if (data['result'] == null) throw Exception('result = null từ server');
    return Map<String, dynamic>.from(data['result'] as Map);
  }

  Future<Map<String, dynamic>> _callNeverHaveIEverApi() =>
      _callGameApi(_ApiUrls.gameNeverHaveIEver);

  Future<Map<String, dynamic>> _callTruthOrDareApi() =>
      _callGameApi(_ApiUrls.gameTruthOrDare);

  Future<Map<String, dynamic>> _callDiceRollApi() =>
      _callGameApi(_ApiUrls.gameDiceRoll);

  // ==========================================================================
  // HELPERS
  // ==========================================================================

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  String _priceText(String? priceRange) {
    switch (priceRange) {
      case null:
      case '':
      case '0':
        return 'Miễn phí';
      case '50-100':  return '50k – 100k';
      case '100-200': return '100k – 200k';
      case '200-500': return '200k – 500k';
      case '500+':    return '500k+';
      default:        return priceRange!;
    }
  }

  // ==========================================================================
  // BUILD
  // ==========================================================================

  @override
  Widget build(BuildContext context) {
    final product     = widget.product;
    final name        = product['name']?.toString() ?? '';
    final description = product['description']?.toString() ?? '';
    final images      = product['images'] as List<dynamic>? ?? [];
    final metaData    = product['meta_data'] as List<dynamic>? ?? [];

    // Parse video URLs from meta
    List<String> videoUrls = [];
    for (final item in metaData) {
      if (item['key'] == 'videos') {
        final raw = item['value'];
        if (raw != null && raw.toString().isNotEmpty) {
          try {
            final decoded = jsonDecode(raw.toString());
            videoUrls = decoded is String
                ? List<String>.from(jsonDecode(decoded) as List)
                : List<String>.from(decoded as List);
          } catch (_) {}
        }
      }
    }

    // 🆕 Ảnh/video "khoảnh khắc bàn nhậu" (_inviteMedia, đã được server xác
    // nhận qua _fetchInviteMedia()) — trước đây chỉ hiện ở mục "Khoảnh khắc"
    // bên dưới, KHÔNG được gộp vào slide chính, nên vừa upload xong quay lại
    // trang chi tiết sẽ không thấy ngay trên slide đầu trang. Giờ gộp thêm
    // vào đây để slide chính luôn phản ánh đúng những gì vừa upload.
    final partyVideoUrls = _inviteMedia.where((m) => m.isVideo).map((m) => m.url).toList();
    final partyImageUrls = _inviteMedia.where((m) => !m.isVideo).map((m) => m.url).toList();

    final mediaList = [
      ...videoUrls.map((url) => {'type': 'video', 'url': url}),
      ...partyVideoUrls.map((url) => {'type': 'video', 'url': url}),
      ...images.map((e) => {'type': 'image', 'url': (e as Map)['src']}),
      ...partyImageUrls.map((url) => {'type': 'image', 'url': url}),
    ];

    // 🔧 FIX: so sánh danh sách URL video hiện tại (gồm cả video "khoảnh
    // khắc") với lần init trước, thay vì dùng cờ `_videoInited` chỉ chạy
    // một lần. Nếu sản phẩm được sửa sau (videoUrls đổi) hoặc có video
    // khoảnh khắc mới được _fetchInviteMedia() trả về, ta re-init lại
    // carousel; nếu không đổi thì bỏ qua để tránh dispose/tạo lại
    // controller không cần thiết mỗi lần rebuild.
    final allVideoUrls = [...videoUrls, ...partyVideoUrls];
    if (!listEquals(_initedVideoUrls, allVideoUrls)) {
      _initedVideoUrls = List<String>.from(allVideoUrls);
      WidgetsBinding.instance.addPostFrameCallback((_) => _initVideos(mediaList));
    }

    String? priceRange;
    for (final item in metaData) {
      if (item['key'] == 'price_range') {
        priceRange = item['value']?.toString();
        break;
      }
    }

    // 🆕 Tiến độ kéo-để-đóng (0 -> 1), dùng để scale/fade toàn trang theo
    // ngón tay khi user vuốt xuống trên carousel.
    final dismissProgress = (_dismissDrag / 260).clamp(0.0, 1.0);
    final screenWidth = MediaQuery.of(context).size.width;
    // Kéo xuống thì trang lệch dần sang phải luôn, tạo cảm giác "thu nhỏ
    // về góc dưới-phải" thay vì tụt thẳng xuống.
    final dismissDx = dismissProgress * screenWidth * 0.35;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // ── Nền full-bleed CÙNG gradient với trang, để khi trang thu nhỏ
          //    lộ ra phần nền phía sau thì đồng bộ màu, không bị chỏi ──────
          const Positioned.fill(child: _GradientBackground(child: SizedBox.expand())),

          AnimatedContainer(
            duration: _isDismissDragging
                ? Duration.zero
                : const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            transform: Matrix4.identity()
              ..translate(dismissDx, _dismissDrag)
              ..scale(1 - dismissProgress * 0.22), // thu nhỏ rõ về góc phải-dưới
            transformAlignment: Alignment.topLeft,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(dismissProgress * 28),
              child: Opacity(
                opacity: 1 - dismissProgress * 0.25,
                child: _GradientBackground(
                  child: SafeArea(
                    child: CustomScrollView(
                      slivers: [
                        // ── Collapsible carousel SliverAppBar ───────────────────────
                        SliverAppBar(
                          pinned: true,
                          expandedHeight: 300,
                          backgroundColor: Colors.transparent,
                          elevation: 0,
                          automaticallyImplyLeading: false,
                          flexibleSpace: FlexibleSpaceBar(
                            collapseMode: CollapseMode.pin,
                            background: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: _buildMediaCarousel(mediaList),
                            ),
                          ),
                          // Back button always visible when pinned
                          leading: _backButton(),
                          actions: [
                            Padding(
                              padding: const EdgeInsets.only(right: 12, top: 8),
                              child: ViewerIndicator(viewerCount: viewerCount),
                            ),
                          ],
                        ),

                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 14),

                                // ── Title & price BELOW the carousel ────────────────
                                _buildHeaderRow(name, _priceText(priceRange)),
                                const SizedBox(height: 16),

                                // 🆕 Khi đang diễn ra: đẩy check-in + "khoảnh khắc"
                                // (feed ảnh/video real-time) lên đầu, đúng lúc cần
                                // dùng nhất là lúc đang ngồi bàn — thay vì phải kéo
                                // xuống mới thấy như bố cục mặc định lúc chưa diễn ra.
                                if (_isLive) ...[
                                  _buildLiveCheckinBanner(),
                                  const SizedBox(height: 16),
                                  _buildMediaSection(),
                                  const SizedBox(height: 16),
                                ],

                                _buildParticipantsSection(),
                                const SizedBox(height: 16),
                                if (!_isLive) ...[
                                  _buildMediaSection(),
                                  const SizedBox(height: 16),
                                ],
                                _buildActionRow(),
                                const SizedBox(height: 16),
                                _buildInfoCard(metaData, description),
                                const SizedBox(height: 32),
                                _buildJoinButton(),
                                const SizedBox(height: 48),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // 🆕 Hiệu ứng pháo hoa khi check-in "Đã tới" thành công — overlay
          // full-screen, không chặn thao tác (IgnorePointer), tự ẩn sau khi
          // animation chạy xong (xem _CheckinFireworkOverlay).
          if (_showCheckinFirework)
            Positioned.fill(
              child: IgnorePointer(
                child: _CheckinFireworkOverlay(
                  onDone: () {
                    if (mounted) setState(() => _showCheckinFirework = false);
                  },
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ==========================================================================
  // BACK BUTTON
  // ==========================================================================

  Widget _backButton() => IconButton(
    icon: Container(
      padding: const EdgeInsets.all(6),
      decoration: const BoxDecoration(
        color: Colors.black26,
        shape: BoxShape.circle,
      ),
      child: const Icon(Icons.arrow_back_ios_new,
          color: Colors.white, size: 18),
    ),
    onPressed: () => Navigator.pop(context),
  );

  // ==========================================================================
  // MEDIA CAROUSEL — swipeable, real video player with controls
  // ==========================================================================

  Widget _buildMediaCarousel(List<Map<String, dynamic>> mediaList) {
    if (mediaList.isEmpty) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 280,
          color: Colors.black26,
          child: const Center(
            child: Icon(Icons.image_not_supported,
                color: Colors.white38, size: 48),
          ),
        ),
      );
    }

    // ── Carousel kiểu "story": auto-play ảnh + progress bar,
    //    double-tap để thả tim ─────────────────────────────────────────────
    return DoubleTapReaction(
      onDoubleTap: () {
        // Chỉ hiệu ứng thị giác. Nếu sau này có endpoint "like invite"
        // thì gọi API ở đây.
      },
      // 🆕 Vuốt xuống trên carousel -> kéo/đóng toàn bộ trang detail.
      onDragUpdate: _onCarouselDragUpdate,
      onDragEnd: _onCarouselDragEnd,
      child: StoryProgressCarousel(
        controller: _storyController,
        itemCount: mediaList.length,
        height: 300,
        borderRadius: BorderRadius.circular(20),
        isVideo: (i) => mediaList[i]['type'] == 'video',
        onIndexChanged: _onPageChanged,
        itemBuilder: (_, i) {
          final item = mediaList[i];
          return item['type'] == 'video'
              ? _buildVideoSlide(item['url'] as String, i)
              : _buildImageSlide(item['url'] as String, index: i);
        },
      ),
    );
  }

  Widget _buildImageSlide(String url, {int index = 0}) {
    final img = CachedNetworkImage(
      imageUrl: url,
      fit: BoxFit.cover,
      width: double.infinity,
      placeholder: (_, __) => _shimmerBox(height: 300),
      errorWidget: (_, __, ___) => Container(
        color: Colors.black26,
        child: const Center(
            child: Icon(Icons.broken_image, color: Colors.white38, size: 40)),
      ),
    );

    // Ảnh đầu tiên dùng Hero để bay mượt từ ShopPage sang đây
    // (nhớ dùng CÙNG tag ở widget ảnh trong list của ShopPage).
    if (index == 0) {
      return Hero(
        tag: 'product-image-${widget.product["id"]}',
        child: img,
      );
    }
    return img;
  }

  Widget _buildVideoSlide(String url, int index) {
    final ctrl = _videoMap[index];
    if (ctrl == null || !ctrl.value.isInitialized) {
      return _shimmerBox(height: 300);
    }
    return _VideoSlide(controller: ctrl);
  }

  // ==========================================================================
  // HEADER — title + price + status badge
  // ==========================================================================

  Widget _buildHeaderRow(String name, String price) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🆕 Badge "Đang diễn ra" — đồng bộ với badge 🔥 ở card ngoài
              // list (shop_page.dart), để không bị "lạc" giao diện khi bấm
              // vào detail lúc kèo đang live.
              if (_isLive) ...[
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF3B30), Color(0xFFFF7043)],
                    ),
                    borderRadius: BorderRadius.circular(100),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF3B30).withOpacity(0.45),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _DetailPulsingDot(),
                      SizedBox(width: 5),
                      Text(
                        'ĐANG DIỄN RA',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
              Text(
                name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  height: 1.25,
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: _AppColors.accentOrange.withOpacity(0.85),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  price,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        _buildInviteStatusBadge(),
      ],
    );
  }

  Widget _buildInviteStatusBadge() {
    // Chưa load xong → không hiện badge
    if (_isLoadingJoin && inviteStatus == null) return const SizedBox.shrink();

    final isOpen   = inviteStatus == 'open';
    final isClosed = inviteStatus != null && !isOpen;

    if (isClosed) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.redAccent.withOpacity(0.16),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
        ),
        child: const Text('Đã đóng',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
      );
    }

    if (isFull) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.orangeAccent.withOpacity(0.16),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.orangeAccent.withOpacity(0.5)),
        ),
        child: const Text('Đã đủ người',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
      );
    }

    // Đang mở → pulse animation
    return ScaleTransition(
      scale: _pulseAnimation,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.green.withOpacity(0.16),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.greenAccent.withOpacity(0.5)),
        ),
        child: const Text('Đang mở',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
      ),
    );
  }

  // ==========================================================================
  // PARTICIPANTS SECTION
  // ==========================================================================

  Widget _buildParticipantsSection() {
    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '👥 Thành viên ($joinedCount/$maxPeople)',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (allowRating)
                _TinyButton(
                  label: 'Đánh giá',
                  icon: Icons.star,
                  color: Colors.blueAccent,
                  onTap: _openRatingSheet,
                ),
            ],
          ),
          // 🆕 Khi đang diễn ra: số người ĐÃ THỰC SỰ CÓ MẶT quan trọng hơn số
          // đã đăng ký — tổng hợp từ AttendanceStatus.going (check-in GPS).
          if (_isLive && !_isLoadingJoin) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.flag_rounded, color: Color(0xFFFF7043), size: 14),
                const SizedBox(width: 5),
                Text(
                  '$_goingCount/$joinedCount đã tới',
                  style: const TextStyle(
                    color: Color(0xFFFF7043),
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 14),
          if (_isLoadingJoin)
            _shimmerParticipants()
          else if (_participants.isEmpty)
            const Center(
              child: Text('Chưa có thành viên',
                  style: TextStyle(color: Colors.white54)),
            )
          else
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _participants.map((p) {
                  final isMe    = p.userId == _currentUserId;
                  final canKick = isHost && !isMe;
                  return Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: _ParticipantCard(
                      participant: p,
                      isMe: isMe,
                      canKick: canKick,
                      isUpdatingAttendance: isMe && _isUpdatingAttendance,
                      onAttendanceTap: isMe ? _showAttendancePicker : null,
                      onKick: () => _kickUser(p.userId),
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }

  // ==========================================================================
  // MEDIA SECTION (uploaded moments)
  // ==========================================================================

  Widget _buildMediaSection() {
    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '📸 Khoảnh khắc bàn nhậu',
                style: TextStyle(
                  color: Colors.orangeAccent,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // 🆕 Xem newsfeed (ảnh/video) đã đăng cho kèo này —
                  // đặt cạnh khu vực media vì đây chính là nơi liên quan
                  // trực tiếp, thay vì trộn chung với các nút hành động
                  // đổi trạng thái (Đã tới / Đóng bàn / Trò chơi).
                  if (widget.product['id'] != null)
                    GestureDetector(
                      onTap: () {
                        final idRaw = widget.product['id'];
                        final pid = int.tryParse(idRaw.toString());
                        if (pid == null) return;
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                NewsfeedPage(initialProductId: pid),
                          ),
                        );
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.orangeAccent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.dynamic_feed_rounded,
                                color: Colors.orangeAccent, size: 16),
                            SizedBox(width: 4),
                            Text(
                              'Newsfeed',
                              style: TextStyle(
                                color: Colors.orangeAccent,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  if (isHost || isJoined)
                    GestureDetector(
                      onTap: _showMediaPicker,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.orangeAccent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.add,
                            color: Colors.orangeAccent, size: 20),
                      ),
                    ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          (_pendingMedia.isEmpty && _inviteMedia.isEmpty)
              ? Container(
            height: 90,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text('Chưa có ảnh hoặc video',
                style: TextStyle(color: Colors.white38)),
          )
          // 🆕 _pendingMedia đứng trước _inviteMedia -> media vừa chọn
          // hiện ngay ở đầu (bên trái, trong tầm nhìn đầu tiên) thay vì
          // phải đợi upload xong rồi mới thấy sau khi fetch lại.
              : SizedBox(
            height: 110,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _pendingMedia.length + _inviteMedia.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                if (i < _pendingMedia.length) {
                  return _buildPendingMediaThumb(_pendingMedia[i]);
                }
                return _buildMediaThumbnail(
                    _inviteMedia[i - _pendingMedia.length]);
              },
            ),
          ),
        ],
      ),
    );
  }

  // 🆕 Thumbnail cho media đang chọn / nén / tải lên (chưa có id server).
  Widget _buildPendingMediaThumb(_PendingMedia item) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 100,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (item.type == 'video')
              item.generatingThumb
                  ? shimmer.Shimmer.fromColors(
                baseColor: Colors.white.withOpacity(0.15),
                highlightColor: Colors.white.withOpacity(0.35),
                child: Container(color: Colors.white),
              )
                  : item.thumbnail != null
                  ? Image.memory(item.thumbnail!, fit: BoxFit.cover)
                  : Container(
                color: Colors.white.withOpacity(0.08),
                child: const Icon(Icons.videocam_rounded, color: Colors.white54),
              )
            else
              Image.file(item.file, fit: BoxFit.cover),
            if (item.uploading)
              Container(
                color: Colors.black.withOpacity(0.55),
                child: Center(
                  child: item.type == 'video'
                      ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 26, height: 26,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          value: item.progress > 0 ? item.progress : null,
                          color: Colors.orangeAccent,
                          backgroundColor: Colors.white.withOpacity(0.15),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${(item.progress * 100).clamp(0, 100).toStringAsFixed(0)}%',
                        style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600),
                      ),
                    ],
                  )
                      : const SizedBox(
                    width: 22, height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.orangeAccent),
                  ),
                ),
              ),
            if (item.error) ...[
              Container(
                color: Colors.black.withOpacity(0.6),
                child: const Center(
                  child: Icon(Icons.error_rounded, color: Colors.redAccent, size: 28),
                ),
              ),
              Positioned(
                top: 4, right: 4,
                child: GestureDetector(
                  onTap: () => setState(() => _pendingMedia.remove(item)),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), shape: BoxShape.circle),
                    child: const Icon(Icons.close, size: 12, color: Colors.white),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildMediaThumbnail(MediaItem item) {
    final canDelete =
        isHost || item.userId == _currentUserId;
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 100,
        child: Stack(
          fit: StackFit.expand,
          children: [
            item.isVideo
                ? GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      FullScreenVideoPage(videoUrl: item.url),
                ),
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // 🆕 Ảnh thumbnail thật của video (thay vì chỉ ô đen).
                  // `key` + cache theo item.id để đảm bảo video thêm sau
                  // không hiện nhầm ảnh của video thêm trước.
                  FutureBuilder<Uint8List?>(
                    key: ValueKey('video_thumb_${item.id}'),
                    future: _getConfirmedVideoThumb(item),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState != ConnectionState.done) {
                        return shimmer.Shimmer.fromColors(
                          baseColor: Colors.white.withOpacity(0.08),
                          highlightColor: Colors.white.withOpacity(0.25),
                          child: Container(color: Colors.white),
                        );
                      }
                      final bytes = snapshot.data;
                      if (bytes == null) {
                        return Container(color: Colors.black38);
                      }
                      return Image.memory(bytes, fit: BoxFit.cover);
                    },
                  ),
                  Container(color: Colors.black.withOpacity(0.18)),
                  const Center(
                    child: Icon(Icons.play_circle_fill,
                        size: 44, color: Colors.white),
                  ),
                ],
              ),
            )
                : CachedNetworkImage(
                imageUrl: item.url, fit: BoxFit.cover),
            if (canDelete)
              Positioned(
                top: 4,
                right: 4,
                child: GestureDetector(
                  onTap: () => _deleteMedia(item.id),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.9),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close,
                        size: 12, color: Colors.white),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ==========================================================================
  // 🆕 LIVE CHECK-IN BANNER (chỉ hiện khi kèo đang diễn ra)
  // ==========================================================================
  //
  // Đẩy hành động quan trọng nhất lúc đang ngồi bàn — xác nhận có mặt +
  // vào trò chơi — lên ngay đầu trang, thay vì để lẫn trong _buildActionRow
  // (vốn còn có "Đóng bàn"/"Mở lại bàn" của host, dễ bị bỏ qua). Chỉ hiện
  // cho người đã join hoặc là host; khách vãng lai xem kèo live nhưng chưa
  // tham gia thì không có gì để check-in nên không hiện.
  Widget _buildLiveCheckinBanner() {
    final bool canCheckin = isJoined || isHost;
    if (!canCheckin) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!_hasCheckedIn)
          _isUpdatingAttendance
              ? shimmer.Shimmer.fromColors(
            baseColor: const Color(0xFFFF7043).withOpacity(0.10),
            highlightColor: const Color(0xFFFF7043).withOpacity(0.35),
            child: Container(
              width: double.infinity,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          )
              : GestureDetector(
            onTap: _checkinWithGps,
            onLongPress: _showAttendancePicker,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
              decoration: BoxDecoration(
                // 🆕 Đổi từ gradient đỏ-cam đặc (chói, dễ lấn át nội dung
                // khác) sang kiểu "kính mờ" trong suốt — vẫn nổi bật nhờ
                // viền + icon/chữ màu san hô, nhưng dịu mắt hơn nhiều.
                color: const Color(0xFFFF7043).withOpacity(0.16),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFFF7043).withOpacity(0.55)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.flag_rounded, color: Color(0xFFFF7043), size: 20),
                  SizedBox(width: 10),
                  Text(
                    'Xác nhận đã tới (check-in)',
                    style: TextStyle(
                      color: Color(0xFFFF7043),
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
          )
        else
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.15),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.green.withOpacity(0.4)),
            ),
            child: const Row(
              children: [
                Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Bạn đã check-in — chúc vui vẻ! 🍻',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13.5),
                  ),
                ),
              ],
            ),
          ),

        const SizedBox(height: 10),

        // 🆕 Trò chơi bàn nhậu — đúng lúc cần dùng nhất là lúc đang ngồi bàn,
        // nên đưa lên ngay đây thay vì chỉ nằm trong _buildActionRow phía dưới.
        Center(
          child: _ChipButton(
            label: 'Trò chơi bàn nhậu 🎲',
            icon: Icons.sports_bar_rounded,
            onTap: _openGameMenu,
            outlined: true,
          ),
        ),

        // 🆕 Nhắc nhở an toàn nhẹ nhàng khi khuya + đang diễn ra — phù hợp
        // trách nhiệm của 1 app nhậu, không chặn hành động nào của user.
        if (_isLateNight) ...[
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Row(
              children: [
                Icon(Icons.nightlight_round, color: Colors.amberAccent, size: 16),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Đã khuya rồi — uống có kiểm soát và nhớ đặt xe về an toàn nhé.',
                    style: TextStyle(color: Colors.white70, fontSize: 12.5),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  // ==========================================================================
  // ACTION ROW (host controls + attendance)
  // ==========================================================================

  Widget _buildActionRow() {
    if (!isHost && !isJoined) return const SizedBox.shrink();
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 8,
      runSpacing: 8,
      children: [
        // 🆕 "Đã tới" là hành động chính (check-in) -> giữ nút gradient nổi
        // bật, các nút còn lại chuyển sang dạng outline nhỏ gọn hơn để đỡ
        // rối mắt và làm rõ đâu là hành động quan trọng nhất.
        // Khi đang diễn ra (_isLive), nút check-in + trò chơi đã được đẩy
        // lên _buildLiveCheckinBanner() ngay đầu trang rồi -> ẩn ở đây để
        // không lặp lại 2 lần cùng 1 hành động trên cùng 1 trang.
        if (isJoined && !_isLive) ...[
          _isUpdatingAttendance
              ? _shimmerChip()
              : _ChipButton(
            label: 'Đã tới',
            icon: Icons.flag,
            onTap: _isUpdatingAttendance ? () {} : _checkinWithGps,
            onLongPress: _showAttendancePicker,
          ),
        ],
        if (isHost) ...[
          _isUpdatingInviteStatus
              ? _shimmerChip()
              : _ChipButton(
            label:
            inviteStatus == 'open' ? 'Đóng bàn' : 'Mở lại bàn',
            icon: inviteStatus == 'open' ? Icons.lock : Icons.lock_open,
            onTap: _toggleInviteStatus,
            outlined: true,
          ),
        ],
        if (isJoined && !_isLive) ...[
          _ChipButton(
            label: 'Trò chơi',
            icon: Icons.sports_bar_rounded,
            onTap: _openGameMenu,
            outlined: true,
          ),
        ],
      ],
    );
  }


  // ==========================================================================
  // INFO CARD
  // ==========================================================================

  Widget _buildInfoCard(List<dynamic> metaData, String description) {
    // ── Map key → (icon, label hiển thị) ──────────────────────────────────
    const fieldDefs = <String, (IconData, String)>{
      'date':         (Icons.calendar_today,  'Ngày'),
      'time':         (Icons.access_time,     'Giờ'),
      'address':      (Icons.location_on,     'Địa điểm'),
      'phone':        (Icons.phone,           'Liên hệ'),
      'contact':      (Icons.contact_phone,   'Liên hệ'),
      'zalo':         (Icons.chat_bubble,     'Zalo'),
      'facebook':     (Icons.people_alt,      'Facebook'),
      'note':         (Icons.notes,           'Ghi chú'),
      'requirements': (Icons.checklist,       'Yêu cầu'),
    };

    // ── Lấy meta hợp lệ theo thứ tự ưu tiên ──────────────────────────────
    final orderedKeys = ['date', 'time', 'address', 'phone', 'contact', 'zalo', 'facebook', 'note', 'requirements'];
    final metaMap = <String, String>{
      for (final m in metaData)
        if (m['key'] != null && m['value'] != null)
          m['key'].toString(): m['value'].toString(),
    };

    final validMeta = orderedKeys
        .where((k) => metaMap.containsKey(k) && metaMap[k]!.isNotEmpty)
        .map((k) => (key: k, value: metaMap[k]!, def: fieldDefs[k]!))
        .toList();

    // 🆕 Giờ / Địa điểm / Liên hệ là 3 thông tin quan trọng nhất khi xem 1
    // kèo -> tách riêng ra thành khối nổi bật (icon lớn, nền đậm hơn) thay
    // vì để lẫn trong grid/row chung chung như các field khác.
    const highlightOrder = ['time', 'address', 'phone', 'contact'];
    final highlightMeta = highlightOrder
        .where((k) => metaMap.containsKey(k) && metaMap[k]!.isNotEmpty)
    // phone/contact chỉ lấy field đầu tiên có giá trị, tránh trùng "Liên hệ"
        .fold<List<({String key, String value, (IconData, String) def})>>(
      [],
          (acc, k) {
        if ((k == 'phone' || k == 'contact') &&
            acc.any((e) => e.key == 'phone' || e.key == 'contact')) {
          return acc;
        }
        acc.add((key: k, value: metaMap[k]!, def: fieldDefs[k]!));
        return acc;
      },
    );
    final highlightKeys = highlightMeta.map((e) => e.key).toSet();
    validMeta.removeWhere((m) => highlightKeys.contains(m.key));

    // ── Số người tham gia ─────────────────────────────────────────────────
    final hasCount = maxPeople > 0;

    // ── Categories ────────────────────────────────────────────────────────
    final cats = widget.product['categories'] as List<dynamic>? ?? [];
    final catNames = cats
        .map((c) => (c as Map<String, dynamic>)['name']?.toString() ?? '')
        .where((n) => n.isNotEmpty)
        .toList();

    final isEmpty = validMeta.isEmpty && highlightMeta.isEmpty && !hasCount && catNames.isEmpty && description.isEmpty;
    if (isEmpty) return const SizedBox.shrink();

    // ── Tách thành 2 nhóm: ngắn (1 dòng) và dài (multi-line) ─────────────
    const shortKeys = {'date', 'time', 'phone', 'contact', 'zalo'};
    final shortMeta = validMeta.where((m) => shortKeys.contains(m.key)).toList();
    final longMeta  = validMeta.where((m) => !shortKeys.contains(m.key)).toList();

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ──────────────────────────────────────────────────────
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _AppColors.accentOrange.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.info_outline,
                    color: _AppColors.accentOrange, size: 16),
              ),
              const SizedBox(width: 10),
              const Text(
                'Thông tin chi tiết',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // ── Giờ / Địa điểm / Liên hệ — nổi bật lên đầu ──────────────────
          if (highlightMeta.isNotEmpty) ...[
            Column(
              children: highlightMeta
                  .map((m) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _HighlightInfoRow(
                  icon: m.def.$1,
                  label: m.def.$2,
                  value: m.value,
                ),
              ))
                  .toList(),
            ),
            const SizedBox(height: 4),
          ],

          // ── Số người tham gia ──────────────────────────────────────────
          if (hasCount) ...[
            _InfoCountBar(joined: joinedCount, max: maxPeople),
            const SizedBox(height: 14),
          ],

          // ── Categories dạng chips ──────────────────────────────────────
          if (catNames.isNotEmpty) ...[
            _InfoLabel(label: 'Danh mục'),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: catNames.map((name) => _CategoryChip(name: name)).toList(),
            ),
            const SizedBox(height: 14),
          ],

          // ── Short fields: grid 2 cột ───────────────────────────────────
          if (shortMeta.isNotEmpty) ...[
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 2.8,
              children: shortMeta.map((m) => _InfoCell(
                icon: m.def.$1,
                label: m.def.$2,
                value: m.value,
              )).toList(),
            ),
            const SizedBox(height: 10),
          ],

          // ── Long fields: full width ────────────────────────────────────
          ...longMeta.map((m) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _InfoRow(icon: m.def.$1, label: m.def.$2, value: m.value),
          )),

          // ── Mô tả HTML ────────────────────────────────────────────────
          if (description.isNotEmpty) ...[
            if (validMeta.isNotEmpty || hasCount || catNames.isNotEmpty)
              Divider(color: Colors.white.withOpacity(0.1), height: 20),
            const SizedBox(height: 4),
            Html(
              data: description,
              style: {
                'body': Style(
                  fontSize: FontSize(14),
                  color: Colors.white.withOpacity(0.88),
                  lineHeight: LineHeight(1.75),
                  margin: Margins.zero,
                  padding: HtmlPaddings.zero,
                ),
              },
            ),
          ],
        ],
      ),
    );
  }

  // ==========================================================================
  // JOIN BUTTON
  // ==========================================================================

  Widget _buildJoinButton() {
    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        transitionBuilder: (child, anim) => ScaleTransition(
          scale: anim,
          child: FadeTransition(opacity: anim, child: child),
        ),
        child: _isLoadingJoin
            ? _shimmerButton()
            : isJoined
            ? _buildJoinedActions()
            : (inviteStatus != 'open' || isFull)
            ? _buildClosedButton()
            : _buildOpenJoinButton(),
      ),
    );
  }

  Widget _buildJoinedActions() => Column(
    key: const ValueKey('joined'),
    children: [
      Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _ActionButton(
            label: 'Chat ($joinedCount)',
            icon: Icons.chat_bubble_rounded,
            color: const Color(0xFF22C55E),
            onTap: _goToGroupChat,
            glass: true,
          ),
          const SizedBox(width: 10),
          _ActionButton(
            label: 'Rời phòng',
            icon: Icons.logout_rounded,
            color: Colors.redAccent,
            onTap: _leaveInvite,
            glass: true,
          ),
        ],
      ),
    ],
  );

  Widget _buildClosedButton() {
    final isFull = inviteStatus == 'open';
    return _ActionButton(
      key: const ValueKey('closed'),
      label: isFull ? 'Đã đủ người' : 'Bàn đã đóng',
      // 🆕 Xám bạc pha ánh xanh (slate) thay vì trắng mờ đơn điệu —
      // trung tính, sang, vẫn đủ tương phản trên nền gradient navy/cam.
      // "Đủ người" dùng icon nhóm, "đã đóng" dùng icon khoá để phân biệt lý do.
      icon: isFull ? Icons.groups_rounded : Icons.lock_rounded,
      color: const Color(0xFF9FB0C3),
      onTap: null,
      glass: true,
    );
  }

  Widget _buildOpenJoinButton() => ScaleTransition(
    scale: _pulseAnimation,
    child: _ActionButton(
      key: const ValueKey('join'),
      label: 'Tham gia buổi nhậu 🍺',
      icon: Icons.group_add_rounded,
      color: _AppColors.accentOrange,
      onTap: inviteId == null ? null : _joinInvite,
      large: true,
      glass: true,
    ),
  );

  Future<void> _goToGroupChat() async {
    if (_currentUserId == null) {
      _showSnack('Chưa xác định được user');
      return;
    }
    final currentUser = await UserHelper.getCurrentUser();
    final username = (currentUser['username'] as String?) ?? 'Người dùng';
    final me = _participants.firstWhere(
          (p) => p.userId == _currentUserId,
      orElse: () => Participant(
        userId: 0, name: '', status: '', role: '',
        attendanceStatus: AttendanceStatus.undecided,
        trustScore: 50,
      ),
    );
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GroupChatPage(
          username:    username,
          userId:      _currentUserId!,
          groupAvatar: me.avatar ?? '',
          groupId:     inviteId!,
          groupName:   widget.product['name']?.toString() ?? 'Nhóm',
        ),
      ),
    );
  }

  // ==========================================================================
  // BOTTOM SHEETS
  // ==========================================================================

  void _showMediaPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _GradientBottomSheet(
        title: '📸 Thêm khoảnh khắc',
        children: [
          _MediaPickerTile(
            icon: Icons.photo_library_rounded,
            title: 'Chọn ảnh',
            subtitle: 'Đăng ảnh lên bàn nhậu',
            onTap: () {
              Navigator.pop(context);
              _pickAndUpload('image');
            },
          ),
          const SizedBox(height: 10),
          _MediaPickerTile(
            icon: Icons.videocam_rounded,
            title: 'Chọn video',
            subtitle: 'Chia sẻ video cùng mọi người',
            onTap: () {
              Navigator.pop(context);
              _pickAndUpload('video');
            },
          ),
        ],
      ),
    );
  }

  void _showAttendancePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _GradientBottomSheet(
        title: '🚩 Trạng thái tham dự',
        children: AttendanceStatus.values.map((s) => ListTile(
          leading: Icon(Icons.circle, color: s.color, size: 12),
          title: Text(s.shortLabel,
              style: const TextStyle(color: Colors.white)),
          onTap: () async {
            Navigator.pop(context);
            if (s == AttendanceStatus.going) {
              await _checkinWithGps();
            } else {
              await _updateAttendance(s);
            }
          },
        )).toList(),
      ),
    );
  }

  void _openRatingSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.4,
        builder: (_, controller) => _GradientBottomSheet(
          title: '⭐ Đánh giá thành viên',
          scrollController: controller,
          children: [
            // 🔥 Không hiện chính mình trong danh sách được đánh giá
            ..._participants
                .where((p) => p.userId != _currentUserId)
                .map((p) => _RatingTile(
              participant: p,
              onRate: (point) async {
                await _rateUser(p.userId, point);
                if (mounted) Navigator.pop(context);
                _openRatingSheet();
              },
            )),
          ],
        ),
      ),
    );
  }

  void _openGameMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _GradientBottomSheet(
        title: '🎮 Trò chơi bàn nhậu',
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: _GameGridTile(
                    icon: Icons.casino_rounded,
                    title: 'Vòng quay nhậu',
                    color: Colors.orangeAccent,
                    onTap: () {
                      Navigator.pop(context);
                      _openSpinDialog();
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _GameGridTile(
                    icon: Icons.local_bar_rounded,
                    title: 'Chưa Từng',
                    color: Colors.lightBlueAccent,
                    onTap: () {
                      Navigator.pop(context);
                      _openNeverHaveIEverDialog();
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: _GameGridTile(
                    icon: Icons.record_voice_over_rounded,
                    title: 'Thật Hay Thách',
                    color: Colors.purpleAccent,
                    onTap: () {
                      Navigator.pop(context);
                      _openTruthOrDareDialog();
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _GameGridTile(
                    icon: Icons.casino,
                    title: 'Xúc Xắc Phạt',
                    color: Colors.redAccent,
                    onTap: () {
                      Navigator.pop(context);
                      _openDiceRollDialog();
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _openSpinDialog() {
    final wheelKey = GlobalKey<SpinWheelState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialogState) => Dialog(
          backgroundColor: Colors.transparent,
          child: _GradientContainer(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  '🎡 Vòng quay nhậu',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                SpinWheel(
                  key: wheelKey,
                  items: const [
                    'Uống 1 ly',
                    'Uống 2 ly',
                    'Chỉ định người khác',
                    'Cả bàn uống',
                  ],
                  onFinish: (index) {
                    Navigator.pop(context);
                    final result = _spinResult;
                    _showSpinResult(
                      result['user_name']?.toString() ?? '',
                      result['action']?.toString() ?? '',
                    );
                  },
                ),
                const SizedBox(height: 16),
                _ActionButton(
                  label: _isSpinningApi ? 'Đang quay...' : '🎲 Quay ngay',
                  color: _AppColors.accentOrange,
                  // ✅ Disable nút trong lúc chờ API để tránh bấm nhiều
                  // lần -> gây gọi spinTo() chồng chéo nhau (nguồn gốc
                  // của lỗi "quay 1 đằng báo 1 nẻo" trước đây).
                  onTap: _isSpinningApi
                      ? null
                      : () async {
                    if (wheelKey.currentState?.isSpinning == true) return;
                    // ✅ FIX: trước đây gọi spinTo(0) "quay mù" ngay lập
                    // tức (trước khi biết kết quả thật), rồi sau khi API
                    // trả về mới gọi spinTo(index) lần 2 tới vị trí
                    // thật. Vì SpinWheel không hủy/ghi đè được animation
                    // đang chạy dở của lần quay đầu, bánh xe có thể dừng
                    // lại ở 1 ô khác với kết quả thật được thông báo ->
                    // "quay 1 đằng báo 1 nẻo". Giờ: gọi API lấy kết quả
                    // thật TRƯỚC, rồi chỉ spinTo() ĐÚNG 1 LẦN DUY NHẤT
                    // tới index thật.
                    setDialogState(() => _isSpinningApi = true);
                    try {
                      final data = await _callSpinWheelApi();
                      setState(() => _spinResult =
                      Map<String, dynamic>.from(data['result'] as Map));
                      wheelKey.currentState
                          ?.spinTo(_spinResult['index'] as int);
                    } catch (e) {
                      _showSnack('❌ $e');
                    } finally {
                      setDialogState(() => _isSpinningApi = false);
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSpinResult(String user, String action) {
    _speak('$user, $action');
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GradientContainer(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.emoji_events, color: Colors.amber, size: 52),
              const SizedBox(height: 10),
              const Text('KẾT QUẢ',
                  style: TextStyle(
                      color: Colors.white60,
                      fontSize: 13,
                      letterSpacing: 1.5)),
              const SizedBox(height: 12),
              Text(user,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(action,
                    style: const TextStyle(
                        fontSize: 16, color: Colors.white)),
              ),
              const SizedBox(height: 20),
              _ActionButton(
                label: 'Đồng ý',
                color: _AppColors.accentOrange,
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

// ==========================================================================
// DIALOG KẾT QUẢ CHUNG CHO CÁC TRÒ MỚI
// ==========================================================================

  /// Chạy [call], hiện loading trong lúc chờ, rồi hiện kết quả qua
  /// [buildResult]. Nếu lỗi thì đóng loading + hiện snack, không crash.
  Future<void> _runGameFlow({
    required Future<Map<String, dynamic>> Function() call,
    required Widget Function(Map<String, dynamic> result) buildResult,
    // 🔊 Câu sẽ được đọc to (TTS) ngay khi kết quả hiện ra. Trả về chuỗi
    // rỗng/null nếu không muốn đọc.
    String? Function(Map<String, dynamic> result)? speechText,
  }) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _GradientContainer(child: _gameLoadingShimmer()),
      ),
    );
    try {
      final result = await call();
      if (!mounted) return;
      Navigator.pop(context); // đóng loading
      _playGameResultSound();
      final text = speechText?.call(result);
      if (text != null && text.trim().isNotEmpty) {
        _speak(text);
      }
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          child: _GradientContainer(child: buildResult(result)),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context); // đóng loading
      _showSnack('❌ $e');
    }
  }

  /// Khung "xương" (shimmer) hiện trong lúc chờ API trả kết quả trò chơi —
  /// mô phỏng đúng bố cục của [_gameResultShell] (icon tròn, tiêu đề, khối
  /// nội dung, nút) để lúc kết quả thật hiện ra không bị giật/nhảy hình.
  Widget _gameLoadingShimmer() {
    return shimmer.Shimmer.fromColors(
      baseColor: Colors.white.withOpacity(0.08),
      highlightColor: Colors.white.withOpacity(0.25),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircleAvatar(radius: 26, backgroundColor: Colors.white),
          const SizedBox(height: 12),
          Container(
            width: 90,
            height: 12,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: 220,
            height: 54,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            width: 160,
            height: 14,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            width: 220,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _gameResultShell({
    required IconData icon,
    required String heading,
    required List<Widget> children,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: Colors.amber, size: 52),
        const SizedBox(height: 10),
        Text(heading,
            style: const TextStyle(
                color: Colors.white60, fontSize: 13, letterSpacing: 1.5)),
        const SizedBox(height: 12),
        ...children,
        const SizedBox(height: 20),
        _ActionButton(
          label: 'Đồng ý',
          color: _AppColors.accentOrange,
          onTap: () => Navigator.pop(context),
        ),
      ],
    );
  }

  void _openNeverHaveIEverDialog() {
    _runGameFlow(
      call: _callNeverHaveIEverApi,
      speechText: (result) => result['statement']?.toString(),
      buildResult: (result) => _gameResultShell(
        icon: Icons.local_bar_rounded,
        heading: 'CHƯA TỪNG',
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              result['statement']?.toString() ?? '',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _openTruthOrDareDialog() {
    _runGameFlow(
      call: _callTruthOrDareApi,
      speechText: (result) {
        final name = result['user_name']?.toString() ?? '';
        final isDare = result['mode']?.toString() == 'dare';
        final content = result['content']?.toString() ?? '';
        final modeLabel = isDare ? 'thách' : 'thật';
        return '$name, $modeLabel: $content';
      },
      buildResult: (result) {
        final isDare = result['mode']?.toString() == 'dare';
        return _gameResultShell(
          icon: Icons.record_voice_over_rounded,
          heading: 'THẬT HAY THÁCH',
          children: [
            Text(result['user_name']?.toString() ?? '',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
            const SizedBox(height: 8),
            Container(
              padding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: (isDare ? Colors.redAccent : Colors.blueAccent)
                    .withOpacity(0.25),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(isDare ? 'THÁCH' : 'THẬT',
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
            ),
            const SizedBox(height: 10),
            Container(
              padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(result['content']?.toString() ?? '',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16, color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  void _openDiceRollDialog() {
    _runGameFlow(
      call: _callDiceRollApi,
      speechText: (result) {
        final name = result['user_name']?.toString() ?? '';
        final dice = result['dice']?.toString() ?? '';
        final penalty = result['penalty']?.toString() ?? '';
        return '$name, xúc xắc ra $dice: $penalty';
      },
      buildResult: (result) => _gameResultShell(
        icon: Icons.casino,
        heading: 'XÚC XẮC PHẠT',
        children: [
          Text(result['user_name']?.toString() ?? '',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white)),
          const SizedBox(height: 8),
          Text('🎲 ${result['dice'] ?? ''}',
              style: const TextStyle(fontSize: 32, color: Colors.white)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(result['penalty']?.toString() ?? '',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, color: Colors.white)),
          ),
        ],
      ),
    );
  }

// ==========================================================================
// SHIMMER HELPERS
// ==========================================================================

  Widget _shimmerBox({double height = 120}) =>
      shimmer.Shimmer.fromColors(
        baseColor: Colors.white.withOpacity(0.06),
        highlightColor: Colors.white.withOpacity(0.18),
        child: Container(
            height: height,
            color: Colors.white,
            width: double.infinity),
      );

  Widget _shimmerButton({double w = 180, double h = 48}) =>
      shimmer.Shimmer.fromColors(
        baseColor: Colors.white.withOpacity(0.08),
        highlightColor: Colors.white.withOpacity(0.4),
        child: Container(
          width: w,
          height: h,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30)),
        ),
      );

  Widget _shimmerChip() => _shimmerButton(w: 92, h: 32);

  Widget _shimmerParticipants() => Row(
    children: List.generate(
      3,
          (_) => Padding(
        padding: const EdgeInsets.only(right: 14),
        child: shimmer.Shimmer.fromColors(
          baseColor: Colors.white.withOpacity(0.08),
          highlightColor: Colors.white.withOpacity(0.25),
          child: Column(
            children: [
              const CircleAvatar(
                  radius: 24, backgroundColor: Colors.white),
              const SizedBox(height: 6),
              Container(
                width: 48,
                height: 10,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5)),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

// =============================================================================
// VIDEO SLIDE — real controls (play/pause + seek bar)
// =============================================================================

class _VideoSlide extends StatefulWidget {
  final VideoPlayerController controller;
  const _VideoSlide({required this.controller});

  @override
  State<_VideoSlide> createState() => _VideoSlideState();
}

class _VideoSlideState extends State<_VideoSlide> {
  bool _showControls = true;
  Timer? _hideTimer;

  VideoPlayerController get _ctrl => widget.controller;

  @override
  void initState() {
    super.initState();
    _ctrl.addListener(_onControllerUpdate);
    _scheduleHide();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _ctrl.removeListener(_onControllerUpdate);
    super.dispose();
  }

  void _onControllerUpdate() {
    if (mounted) setState(() {});
  }

  void _togglePlayPause() {
    setState(() {
      if (_ctrl.value.isPlaying) {
        _ctrl.pause();
        _showControls = true;
        _hideTimer?.cancel();
      } else {
        _ctrl.play();
        _scheduleHide();
      }
    });
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => _showControls = false);
    });
  }

  void _onTap() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHide();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final total    = _ctrl.value.duration;
    final position = _ctrl.value.position;
    final progress = total.inMilliseconds > 0
        ? (position.inMilliseconds / total.inMilliseconds).clamp(0.0, 1.0)
        : 0.0;

    return GestureDetector(
      onTap: _onTap,
      behavior: HitTestBehavior.opaque,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Video frame
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: _ctrl.value.size.width,
              height: _ctrl.value.size.height,
              child: VideoPlayer(_ctrl),
            ),
          ),

          // Dark overlay when controls visible
          AnimatedOpacity(
            opacity: _showControls ? 1.0 : 0.0,
            duration: const Duration(milliseconds: 200),
            child: IgnorePointer(
              ignoring: !_showControls,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // Play / Pause button (centre)
                  Expanded(
                    child: Center(
                      child: GestureDetector(
                        onTap: _togglePlayPause,
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.45),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            _ctrl.value.isPlaying
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                            color: Colors.white,
                            size: 34,
                          ),
                        ),
                      ),
                    ),
                  ),

                  // Seek bar + time
                  Container(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Colors.black.withOpacity(0.6),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                    child: Column(
                      children: [
                        SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            trackHeight: 3,
                            thumbShape: const RoundSliderThumbShape(
                                enabledThumbRadius: 6),
                            overlayShape: const RoundSliderOverlayShape(
                                overlayRadius: 12),
                            activeTrackColor: _AppColors.accentOrange,
                            inactiveTrackColor: Colors.white30,
                            thumbColor: Colors.white,
                            overlayColor: Colors.white24,
                          ),
                          child: Slider(
                            value: progress,
                            onChanged: (v) {
                              final target = Duration(
                                milliseconds:
                                (v * total.inMilliseconds).round(),
                              );
                              _ctrl.seekTo(target);
                              _scheduleHide();
                            },
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              _fmt(position),
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 11),
                            ),
                            Text(
                              _fmt(total),
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 11),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// REUSABLE WIDGETS
// =============================================================================

class _GradientBackground extends StatelessWidget {
  final Widget child;
  const _GradientBackground({required this.child});

  @override
  Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        colors: [Color(0xF20D47A1), Color(0xD9F57C00)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    child: child,
  );
}

class _GradientContainer extends StatelessWidget {
  final Widget child;
  const _GradientContainer({required this.child});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        colors: [Color(0xF20D47A1), Color(0xE5F57C00)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(20),
      boxShadow: const [
        BoxShadow(
            color: Colors.black38, blurRadius: 20, offset: Offset(0, 10))
      ],
    ),
    child: child,
  );
}

class _GradientBottomSheet extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final ScrollController? scrollController;

  const _GradientBottomSheet({
    required this.title,
    required this.children,
    this.scrollController,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        colors: [Color(0xF20D47A1), Color(0xE5F57C00)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      borderRadius:
      BorderRadius.vertical(top: Radius.circular(24)),
    ),
    child: SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 10),
          Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: 14),
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ...children,
          const SizedBox(height: 16),
        ],
      ),
    ),
  );
}

class _SectionCard extends StatelessWidget {
  final Widget child;
  const _SectionCard({required this.child});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.07),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: Colors.white.withOpacity(0.1)),
      boxShadow: const [
        BoxShadow(
            color: Colors.black26, blurRadius: 12, offset: Offset(0, 4))
      ],
    ),
    child: child,
  );
}

class _ActionButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final Color color;
  final VoidCallback? onTap;
  final bool large;
  final bool glass;

  const _ActionButton({
    super.key,
    required this.label,
    required this.color,
    this.icon,
    this.onTap,
    this.large = false,
    this.glass = false,
  });

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton> {
  // 🆕 Cờ theo dõi trạng thái đang giữ nhấn, dùng để "lún" nút xuống
  // (scale nhỏ lại + bóng thu gọn) mỗi khi người dùng chạm — tạo cảm
  // giác phản hồi vật lý 3D thay vì chỉ đổi màu ripple mặc định.
  bool _pressed = false;

  void _setPressed(bool value) {
    if (widget.onTap == null) return;
    setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    final label = widget.label;
    final icon = widget.icon;
    final color = widget.color;
    final large = widget.large;

    // 🆕 Kiểu "chip 3D trong suốt": lấy layout nhỏ gọn kiểu _CategoryChip
    // (viền màu mảnh, bo tròn, icon nhỏ + label) nhưng KHÔNG có màu nền —
    // hoàn toàn trong suốt để lộ gradient phía sau. Chiều sâu 3D được tạo
    // bằng highlight sáng góc trên-trái; khi nhấn, highlight thu nhỏ +
    // nút hơi co lại để mô phỏng việc bị ấn lún xuống.
    if (widget.glass) {
      return GestureDetector(
        onTapDown: (_) => _setPressed(true),
        onTapUp: (_) => _setPressed(false),
        onTapCancel: () => _setPressed(false),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _pressed ? 0.94 : 1.0,
          duration: const Duration(milliseconds: 110),
          curve: Curves.easeOut,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 110),
            padding: EdgeInsets.symmetric(
              horizontal: large ? 30 : 16,
              vertical: large ? 12 : 9,
            ),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(
                color: enabled
                    ? color.withOpacity(_pressed ? 0.75 : 0.55)
                    : color.withOpacity(0.4),
                width: 1.2,
              ),
              boxShadow: !enabled || _pressed
                  ? const []
                  : [
                // Highlight phía trên-trái, biến mất khi đang nhấn
                // để tạo cảm giác nút bị ấn lún vào mặt phẳng.
                BoxShadow(
                  color: color.withOpacity(0.22),
                  blurRadius: 8,
                  offset: const Offset(-2, -2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  Icon(icon,
                      color: enabled ? color : color.withOpacity(0.65),
                      size: large ? 20 : 15),
                  const SizedBox(width: 6),
                ],
                Text(
                  label,
                  style: TextStyle(
                    color: enabled ? Colors.white : Colors.white.withOpacity(0.62),
                    fontSize: large ? 16 : 13,
                    fontWeight: FontWeight.w600,
                    shadows: const [
                      Shadow(color: Colors.black45, blurRadius: 3),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // 🆕 Nút đặc (solid) cũng đổi sang tự vẽ để có hiệu ứng "lún" 3D khi
    // nhấn: bóng đổ dày khi ở trạng thái nghỉ, thu gọn + dịch xuống khi
    // giữ nhấn, giả lập nút vật lý được ấn vào mặt phẳng.
    return GestureDetector(
      onTapDown: (_) => _setPressed(true),
      onTapUp: (_) => _setPressed(false),
      onTapCancel: () => _setPressed(false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 110),
          padding: EdgeInsets.symmetric(
            horizontal: large ? 36 : 20,
            vertical: large ? 14 : 12,
          ),
          decoration: BoxDecoration(
            color: enabled ? color : Colors.white12,
            borderRadius: BorderRadius.circular(30),
            boxShadow: enabled
                ? [
              BoxShadow(
                color: color.withOpacity(_pressed ? 0.18 : 0.4),
                blurRadius: _pressed ? 4 : 10,
                offset:
                _pressed ? const Offset(0, 1) : const Offset(0, 4),
              ),
            ]
                : const [],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon,
                    color: enabled ? Colors.white : Colors.white54,
                    size: large ? 22 : 18),
                const SizedBox(width: 8),
              ],
              Text(
                label,
                style: TextStyle(
                  color: enabled ? Colors.white : Colors.white54,
                  fontSize: large ? 16 : 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 🆕 Chấm nhấp nháy cho badge "ĐANG DIỄN RA" ở header trang chi tiết —
// bản sao nhỏ của _PulsingDot bên shop_page.dart (không import được vì
// class đó private theo library/file, không phải theo class).
class _DetailPulsingDot extends StatefulWidget {
  const _DetailPulsingDot();

  @override
  State<_DetailPulsingDot> createState() => _DetailPulsingDotState();
}

class _DetailPulsingDotState extends State<_DetailPulsingDot> {
  bool _grow = true;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: _grow ? 0.55 : 1.0, end: _grow ? 1.0 : 0.55),
      duration: const Duration(milliseconds: 700),
      onEnd: () {
        if (mounted) setState(() => _grow = !_grow);
      },
      builder: (context, scale, child) {
        return Opacity(
          opacity: scale,
          child: Transform.scale(scale: scale, child: child),
        );
      },
      child: Container(
        width: 6,
        height: 6,
        decoration: const BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

// =============================================================================
// 🆕 CHECK-IN FIREWORK OVERLAY
// =============================================================================
// Hiệu ứng pháo hoa nhẹ khi user check-in "Đã tới" thành công. Tự vẽ bằng
// CustomPainter (không thêm package ngoài nào) — 3 đợt nổ so le thời gian ở
// vài vị trí trên màn hình, mỗi đợt là các hạt màu bắn ra từ tâm rồi rơi/mờ
// dần. Tự gọi onDone() khi animation kết thúc để widget cha ẩn overlay đi.
class _FireworkParticle {
  final Offset originFraction; // vị trí tâm nổ, tính theo tỉ lệ (0-1) của size màn hình
  final double angle;
  final double speed; // bán kính tối đa hạt bay ra được (px)
  final Color color;
  final double radius;
  final double startT; // thời điểm bắt đầu (0-1, theo animation tổng)
  final double endT;   // thời điểm hạt tắt hẳn (0-1)

  _FireworkParticle({
    required this.originFraction,
    required this.angle,
    required this.speed,
    required this.color,
    required this.radius,
    required this.startT,
    required this.endT,
  });
}

class _CheckinFireworkOverlay extends StatefulWidget {
  final VoidCallback onDone;
  const _CheckinFireworkOverlay({required this.onDone});

  @override
  State<_CheckinFireworkOverlay> createState() => _CheckinFireworkOverlayState();
}

class _CheckinFireworkOverlayState extends State<_CheckinFireworkOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<_FireworkParticle> _particles;

  static const _palette = [
    Color(0xFFFF7043), // san hô — đồng bộ màu accent check-in
    Color(0xFFFFC107), // vàng hổ phách
    Color(0xFF4CAF50), // xanh lá
    Color(0xFF29B6F6), // xanh dương nhạt
    Color(0xFFEC407A), // hồng
    Colors.white,
  ];

  @override
  void initState() {
    super.initState();
    _particles = _generateParticles();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        widget.onDone();
      }
    });
    _controller.forward();
  }

  List<_FireworkParticle> _generateParticles() {
    final rand = Random();
    // 3 đợt nổ so le — vị trí ngẫu nhiên ở nửa trên màn hình, thời điểm
    // bắt đầu lệch nhau để trông như 1 màn pháo hoa thật thay vì nổ 1 phát.
    final bursts = [
      (dx: 0.5, dy: 0.30, start: 0.0),
      (dx: 0.25, dy: 0.42, start: 0.18),
      (dx: 0.75, dy: 0.38, start: 0.32),
    ];

    final particles = <_FireworkParticle>[];
    for (final burst in bursts) {
      final count = 22 + rand.nextInt(8);
      for (int i = 0; i < count; i++) {
        final angle = rand.nextDouble() * 2 * pi;
        particles.add(_FireworkParticle(
          originFraction: Offset(burst.dx, burst.dy),
          angle: angle,
          speed: 55 + rand.nextDouble() * 85,
          color: _palette[rand.nextInt(_palette.length)],
          radius: 2 + rand.nextDouble() * 2.2,
          startT: burst.start,
          endT: (burst.start + 0.62).clamp(0.0, 1.0),
        ));
      }
    }
    return particles;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return CustomPaint(
          size: Size.infinite,
          painter: _FireworkPainter(particles: _particles, t: _controller.value),
        );
      },
    );
  }
}

class _FireworkPainter extends CustomPainter {
  final List<_FireworkParticle> particles;
  final double t;

  _FireworkPainter({required this.particles, required this.t});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    for (final p in particles) {
      if (t < p.startT || t > p.endT) continue;

      final span = (p.endT - p.startT).clamp(0.0001, 1.0);
      final localT = ((t - p.startT) / span).clamp(0.0, 1.0);

      // Bán kính bay ra chậm dần (easeOut), thêm chút rơi xuống theo trọng
      // lực để giống pháo hoa thật hơn là nổ tròn đều vô hồn.
      final eased = Curves.easeOut.transform(localT);
      final dist = p.speed * eased;
      final gravityDrop = 40 * localT * localT;

      final dx = p.originFraction.dx * size.width + cos(p.angle) * dist;
      final dy = p.originFraction.dy * size.height + sin(p.angle) * dist + gravityDrop;

      final opacity = (1 - localT).clamp(0.0, 1.0);
      if (opacity <= 0) continue;

      paint.color = p.color.withOpacity(opacity);
      canvas.drawCircle(Offset(dx, dy), p.radius * (1 - localT * 0.35), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _FireworkPainter oldDelegate) => oldDelegate.t != t;
}

class _ChipButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final bool outlined;
  final Color? color;

  const _ChipButton({
    required this.label,
    required this.icon,
    required this.onTap,
    this.onLongPress,
    this.outlined = false,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    // 🆕 Nút phụ (outlined) mặc định dùng tông trắng trung tính, hợp với
    // nền gradient navy → cam san hô sẵn có của app, thay vì màu Material
    // rời rạc (tím/vàng/xanh dương) không cùng bảng màu thương hiệu.
    final accent = color ?? Colors.white;

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        padding:
        const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: outlined
            ? BoxDecoration(
          color: Colors.white.withOpacity(0.10),
          borderRadius: BorderRadius.circular(11),
          border: Border.all(color: Colors.white.withOpacity(0.35)),
        )
            : BoxDecoration(
          gradient: const LinearGradient(
              colors: [Color(0xFFF57C00), Color(0xFFFF3D00)]),
          borderRadius: BorderRadius.circular(11),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26,
                blurRadius: 4,
                offset: Offset(0, 3))
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon,
                size: 14,
                color: outlined ? accent : Colors.white),
            const SizedBox(width: 5),
            Text(label,
                style: TextStyle(
                    color: outlined ? accent : Colors.white,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _TinyButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _TinyButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.85),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.white),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    ),
  );
}

class _MediaPickerTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _MediaPickerTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child:
              Icon(icon, color: Colors.orangeAccent, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 3),
                  Text(subtitle,
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios,
                color: Colors.white38, size: 14),
          ],
        ),
      ),
    ),
  );
}

class _GameGridTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;

  const _GameGridTile({
    required this.icon,
    required this.title,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.18),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
                height: 1.2,
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

// =============================================================================
// PARTICIPANT CARD — tap avatar to change attendance
// =============================================================================

class _ParticipantCard extends StatelessWidget {
  final Participant participant;
  final bool isMe;
  final bool canKick;
  final bool isUpdatingAttendance;
  final VoidCallback? onAttendanceTap;
  final VoidCallback onKick;

  const _ParticipantCard({
    required this.participant,
    required this.isMe,
    required this.canKick,
    required this.isUpdatingAttendance,
    required this.onKick,
    this.onAttendanceTap,
  });

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      GestureDetector(
        onTap: onAttendanceTap,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            // Avatar
            ClipOval(
              child: CachedNetworkImage(
                imageUrl: participant.avatar ?? _ApiUrls.defaultAvatar,
                width: 48,
                height: 48,
                fit: BoxFit.cover,
                errorWidget: (_, __, ___) => const Icon(Icons.person,
                    size: 32, color: Colors.white54),
              ),
            ),
            // Me indicator ring
            if (isMe)
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: _AppColors.accentOrange, width: 2),
                  ),
                ),
              ),
            // Host crown icon — góc trên trái avatar
            if (participant.role == 'host')
              const Positioned(
                top: -10,
                left: -4,
                child: Text('👑', style: TextStyle(fontSize: 18)),
              ),
            // Kick button
            if (canKick)
              Positioned(
                top: -5,
                right: -5,
                child: GestureDetector(
                  onTap: onKick,
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    decoration: const BoxDecoration(
                        color: Colors.red, shape: BoxShape.circle),
                    child: const Icon(Icons.close,
                        size: 11, color: Colors.white),
                  ),
                ),
              ),
            // Trust score badge
            // 🆕 FIX: trước đây LUÔN xanh lá bất kể điểm cao/thấp — không
            // phản ánh đúng ý nghĩa "uy tín", nhìn vào không phân biệt được
            // user điểm 90 hay điểm 10. Giờ màu đổi theo mức điểm (xanh lá
            // ≥70, cam 40-69, đỏ <40) và chuyển sang kiểu trong suốt/viền
            // thay vì nền đặc, đỡ chói trên avatar.
            Positioned(
              bottom: -4,
              right: -4,
              child: Builder(builder: (_) {
                final score = participant.trustScore;
                final Color scoreColor = score >= 70
                    ? Colors.greenAccent
                    : (score >= 40 ? Colors.orangeAccent : Colors.redAccent);
                return Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 4, vertical: 2),
                  decoration: BoxDecoration(
                    color: scoreColor.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: scoreColor.withOpacity(0.75), width: 1),
                  ),
                  child: Text(
                    '$score',
                    style: TextStyle(
                        color: scoreColor,
                        fontSize: 9,
                        fontWeight: FontWeight.bold),
                  ),
                );
              }),
            ),
          ],
        ),
      ),
      // 🆕 Avatar có badge điểm trust_score tràn xuống dưới (bottom: -4),
      // nên cần chừa khoảng cách rõ ràng ở đây, không thì tên bị đè/dính
      // sát ngay dưới badge đó.
      const SizedBox(height: 8),
      // Tên
      SizedBox(
        width: 64,
        child: Text(
          participant.name,
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Colors.white70, fontSize: 11),
        ),
      ),
      const SizedBox(height: 4),
      isUpdatingAttendance
          ? _AttendanceShimmer()
          : _AttendanceBadge(status: participant.attendanceStatus),
    ],
  );
}

class _AttendanceBadge extends StatelessWidget {
  final AttendanceStatus status;
  const _AttendanceBadge({required this.status});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
    decoration: BoxDecoration(
      color: status.color.withOpacity(0.85),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Text(
      status.shortLabel,
      style: const TextStyle(
          color: Colors.white,
          fontSize: 9,
          fontWeight: FontWeight.w600),
    ),
  );
}

class _AttendanceShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) => shimmer.Shimmer.fromColors(
    baseColor: Colors.white.withOpacity(0.15),
    highlightColor: Colors.white.withOpacity(0.5),
    child: Container(
      width: 52,
      height: 14,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8)),
    ),
  );
}

// =============================================================================
// RATING TILE
// =============================================================================

class _RatingTile extends StatelessWidget {
  final Participant participant;
  final void Function(int point) onRate;

  const _RatingTile({required this.participant, required this.onRate});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundImage: NetworkImage(
                participant.avatar ?? _ApiUrls.defaultAvatar),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(participant.name,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold)),
                Text('Uy tín: ${participant.trustScore}',
                    style: const TextStyle(
                        color: Colors.white54, fontSize: 12)),
                if (participant.isRated)
                  Text(
                    participant.myRating == 1
                        ? '👍 Đã đánh giá'
                        : '👎 Đã đánh giá',
                    style: const TextStyle(
                        color: Colors.white30, fontSize: 11),
                  ),
              ],
            ),
          ),
          Row(
            children: [
              _VoteButton(
                icon: Icons.thumb_up,
                color: Colors.green,
                disabled: participant.isRated,
                active: participant.isRated &&
                    participant.myRating == 1,
                onTap: () => onRate(1),
              ),
              const SizedBox(width: 6),
              _VoteButton(
                icon: Icons.thumb_down,
                color: Colors.red,
                disabled: participant.isRated,
                active: participant.isRated &&
                    participant.myRating == -1,
                onTap: () => onRate(-1),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

class _VoteButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final bool disabled;
  final bool active;
  final VoidCallback onTap;

  const _VoteButton({
    required this.icon,
    required this.color,
    required this.disabled,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: disabled ? null : onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: active
            ? color.withOpacity(0.9)
            : color.withOpacity(0.14),
      ),
      child: Icon(icon,
          size: 16,
          color: active
              ? Colors.white
              : (disabled ? Colors.white24 : color)),
    ),
  );
}

// =============================================================================
// VIEWER INDICATOR
// =============================================================================

class ViewerIndicator extends StatefulWidget {
  final int viewerCount;
  const ViewerIndicator({super.key, required this.viewerCount});

  @override
  State<ViewerIndicator> createState() => _ViewerIndicatorState();
}

class _ViewerIndicatorState extends State<ViewerIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.4),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Icon(
            Icons.circle,
            size: 8,
            color: Colors.red
                .withOpacity(0.4 + _ctrl.value * 0.6),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          '${widget.viewerCount} đang xem',
          style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500),
        ),
      ],
    ),
  );
}

// =============================================================================
// FULL SCREEN VIDEO PAGE
// =============================================================================

class FullScreenVideoPage extends StatefulWidget {
  final String videoUrl;
  const FullScreenVideoPage({super.key, required this.videoUrl});

  @override
  State<FullScreenVideoPage> createState() => _FullScreenVideoPageState();
}

class _FullScreenVideoPageState extends State<FullScreenVideoPage> {
  late VideoPlayerController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _ctrl.play();
        _ctrl.setLooping(true);
      });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: _ctrl.value.isInitialized
        ? _VideoSlide(controller: _ctrl)
        : const Center(
        child: CircularProgressIndicator(color: Colors.white)),
  );
}

// =============================================================================
// INFO CARD HELPER WIDGETS
// =============================================================================

/// Label nhỏ trên section (Danh mục, v.v.)
class _InfoLabel extends StatelessWidget {
  final String label;
  const _InfoLabel({required this.label});

  @override
  Widget build(BuildContext context) => Text(
    label,
    style: TextStyle(
      color: Colors.white.withOpacity(0.55),
      fontSize: 11,
      fontWeight: FontWeight.w600,
      letterSpacing: 0.5,
    ),
  );
}

/// Progress bar số người tham gia
class _InfoCountBar extends StatelessWidget {
  final int joined;
  final int max;
  const _InfoCountBar({required this.joined, required this.max});

  @override
  Widget build(BuildContext context) {
    final ratio = max > 0 ? (joined / max).clamp(0.0, 1.0) : 0.0;
    final isFull = joined >= max;
    final barColor = isFull ? Colors.redAccent : _AppColors.accentOrange;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.group, color: barColor, size: 16),
              const SizedBox(width: 8),
              Text(
                'Số người tham gia',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 12,
                    fontWeight: FontWeight.w500),
              ),
              const Spacer(),
              Text(
                '$joined / $max',
                style: TextStyle(
                  color: barColor,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 5,
              backgroundColor: Colors.white.withOpacity(0.1),
              valueColor: AlwaysStoppedAnimation<Color>(barColor),
            ),
          ),
        ],
      ),
    );
  }
}

/// Chip cho từng category
class _CategoryChip extends StatelessWidget {
  final String name;
  const _CategoryChip({required this.name});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: _AppColors.accentOrange.withOpacity(0.18),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: _AppColors.accentOrange.withOpacity(0.35)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.label_rounded,
            color: _AppColors.accentOrange, size: 12),
        const SizedBox(width: 5),
        Text(
          name,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    ),
  );
}

/// Ô thông tin nhỏ 2 cột (date, time, phone, v.v.)
class _InfoCell extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _InfoCell({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.06),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.white.withOpacity(0.08)),
    ),
    child: Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: _AppColors.accentOrange.withOpacity(0.15),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: _AppColors.accentOrange, size: 14),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                value,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

/// Row thông tin dài (address, note, requirements)
/// Hàng thông tin nổi bật (Giờ / Địa điểm / Liên hệ) — icon to hơn, nền
/// đậm màu cam hơn hẳn _InfoRow thường để bắt mắt ngay khi lướt xuống.
class _HighlightInfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _HighlightInfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [
          _AppColors.accentOrange.withOpacity(0.22),
          _AppColors.accentOrange.withOpacity(0.08),
        ],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _AppColors.accentOrange.withOpacity(0.35)),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
            color: _AppColors.accentOrange.withOpacity(0.25),
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(icon, color: _AppColors.accentOrange, size: 19),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.65),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  height: 1.3,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.06),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.white.withOpacity(0.08)),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: _AppColors.accentOrange.withOpacity(0.15),
            borderRadius: BorderRadius.circular(9),
          ),
          child: Icon(icon, color: _AppColors.accentOrange, size: 16),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

// =============================================================================
// STORY PROGRESS CAROUSEL — carousel auto-play kiểu story (thay dot indicator
// bằng progress bar tự chạy, tap trái/phải để lùi/tiến). Ảnh tự auto-advance,
// video giữ nguyên hành vi cũ (không auto-advance, bạn tự vuốt).
// =============================================================================

class StoryProgressController {
  _StoryProgressCarouselState? _state;

  void _attach(_StoryProgressCarouselState state) => _state = state;

  /// Gọi khi muốn ép carousel nhảy sang slide kế tiếp theo cách thủ công
  /// (ví dụ nếu sau này bạn muốn video tự next khi phát xong).
  void next() => _state?._goToNext();

  void previous() => _state?._goToPrevious();

  void pause() => _state?._pause();

  void resume() => _state?._resume();
}

class StoryProgressCarousel extends StatefulWidget {
  final int itemCount;
  final IndexedWidgetBuilder itemBuilder;
  final bool Function(int index) isVideo;
  final Duration imageDuration;
  final ValueChanged<int>? onIndexChanged;
  final StoryProgressController? controller;
  final double height;
  final BorderRadius borderRadius;

  const StoryProgressCarousel({
    super.key,
    required this.itemCount,
    required this.itemBuilder,
    required this.isVideo,
    this.imageDuration = const Duration(seconds: 5),
    this.onIndexChanged,
    this.controller,
    this.height = 300,
    this.borderRadius = const BorderRadius.all(Radius.circular(20)),
  });

  @override
  State<StoryProgressCarousel> createState() => _StoryProgressCarouselState();
}

class _StoryProgressCarouselState extends State<StoryProgressCarousel>
    with SingleTickerProviderStateMixin {
  late final PageController _pageController;
  late final AnimationController _progressController;
  int _index = 0;
  bool _paused = false;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _progressController = AnimationController(vsync: this);
    widget.controller?._attach(this);
    _startCurrent();
  }

  @override
  void didUpdateWidget(covariant StoryProgressCarousel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      widget.controller?._attach(this);
    }
  }

  @override
  void dispose() {
    _progressController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void _startCurrent() {
    _progressController.stop();
    _progressController.reset();

    final isVideo = widget.itemCount > 0 && widget.isVideo(_index);
    if (isVideo) {
      // Video tự quản lý bằng VideoPlayerController có sẵn của bạn —
      // progress bar đứng yên, không auto-advance.
      return;
    }

    _progressController.duration = widget.imageDuration;
    _progressController.forward();
    _progressController.addStatusListener(_onAnimationStatus);
  }

  void _onAnimationStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      _progressController.removeStatusListener(_onAnimationStatus);
      _goToNext();
    }
  }

  void _goToNext() {
    if (_index >= widget.itemCount - 1) return;
    _pageController.nextPage(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOut,
    );
  }

  void _goToPrevious() {
    if (_index <= 0) return;
    _pageController.previousPage(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOut,
    );
  }

  void _pause() {
    _paused = true;
    _progressController.stop();
  }

  void _resume() {
    if (!_paused) return;
    _paused = false;
    _progressController.forward();
  }

  void _onPageChangedInternal(int i) {
    setState(() => _index = i);
    widget.onIndexChanged?.call(i);
    _startCurrent();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.itemCount == 0) return const SizedBox.shrink();

    return ClipRRect(
      borderRadius: widget.borderRadius,
      child: SizedBox(
        height: widget.height,
        child: Stack(
          children: [
            PageView.builder(
              controller: _pageController,
              itemCount: widget.itemCount,
              onPageChanged: _onPageChangedInternal,
              itemBuilder: widget.itemBuilder,
            ),

            // ── Tap trái/phải để lùi/tiến (giống story) ─────────────────
            Positioned.fill(
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTapUp: (_) => _goToPrevious(),
                      onLongPressStart: (_) => _pause(),
                      onLongPressEnd: (_) => _resume(),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTapUp: (_) => _goToNext(),
                      onLongPressStart: (_) => _pause(),
                      onLongPressEnd: (_) => _resume(),
                    ),
                  ),
                ],
              ),
            ),

            // ── Thanh progress kiểu story ────────────────────────────────
            if (widget.itemCount > 1)
              Positioned(
                top: 10,
                left: 10,
                right: 10,
                child: Row(
                  children: List.generate(widget.itemCount, (i) {
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(3),
                          child: SizedBox(
                            height: 3,
                            child: AnimatedBuilder(
                              animation: _progressController,
                              builder: (_, __) {
                                double value;
                                if (i < _index) {
                                  value = 1.0;
                                } else if (i == _index) {
                                  value = widget.isVideo(_index)
                                      ? 0.0
                                      : _progressController.value;
                                } else {
                                  value = 0.0;
                                }
                                return LinearProgressIndicator(
                                  value: value,
                                  backgroundColor:
                                  Colors.white.withOpacity(0.3),
                                  valueColor: const AlwaysStoppedAnimation(
                                      Colors.white),
                                  minHeight: 3,
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ),

            // ── Gradient đáy giữ nguyên cảm giác cũ ─────────────────────
            Positioned.fill(
              child: IgnorePointer(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.45),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================================
// DOUBLE TAP REACTION — double-tap để thả tim, bay lên rồi biến mất
// =============================================================================

class DoubleTapReaction extends StatefulWidget {
  final Widget child;
  final VoidCallback? onDoubleTap;
  final IconData icon;
  final Color color;

  // 🆕 Vuốt xuống trên carousel để đóng trang: bản thân widget này chỉ
  // BẮT gesture (vì user đặt tay lên vùng ảnh/video), còn hiệu ứng kéo
  // thực tế được áp lên TOÀN BỘ trang ở cấp ProductDetailPage thông qua
  // 2 callback dưới đây, chứ không tự vẽ transform cho riêng carousel.
  final ValueChanged<double>? onDragUpdate; // dy cộng dồn khi đang kéo
  final void Function(double dy, double velocity)? onDragEnd;

  const DoubleTapReaction({
    super.key,
    required this.child,
    this.onDoubleTap,
    this.icon = Icons.favorite,
    this.color = const Color(0xFFFF4D6D),
    this.onDragUpdate,
    this.onDragEnd,
  });

  @override
  State<DoubleTapReaction> createState() => _DoubleTapReactionState();
}

class _FloatingHeart {
  final double dx;
  final double startOffset;
  _FloatingHeart({required this.dx, required this.startOffset});
}

class _DoubleTapReactionState extends State<DoubleTapReaction> {
  final List<_FloatingHeart> _hearts = [];
  final _random = Random();

  // 🆕 Vuốt XUỐNG ngay trên vùng ảnh/video để đóng trang detail — tiện
  // hơn cho user thay vì phải bấm nút back. Chỉ nhận drag hướng xuống;
  // vuốt lên vẫn được bỏ qua bình thường (không đóng, không giữ gesture).
  // LƯU Ý: widget này KHÔNG tự vẽ hiệu ứng kéo cho riêng nó nữa — nó chỉ
  // bắt gesture rồi báo dy lên ProductDetailPage qua onDragUpdate/onDragEnd
  // để cả trang (title, giá, mô tả...) cùng trượt theo, không chỉ mỗi
  // carousel.
  double _dragDy = 0;

  void _handleDoubleTap(TapDownDetails details, BoxConstraints constraints) {
    final dxRatio =
    (details.localPosition.dx / constraints.maxWidth).clamp(0.15, 0.85);
    final heart = _FloatingHeart(
      dx: dxRatio,
      startOffset: _random.nextDouble() * 20 - 10,
    );
    setState(() => _hearts.add(heart));

    Timer(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _hearts.remove(heart));
    });

    widget.onDoubleTap?.call();
  }

  void _onVerticalDragUpdate(DragUpdateDetails details) {
    // Chỉ tích luỹ khi kéo XUỐNG (delta.dy > 0). Nếu đang ở vị trí gốc
    // (_dragDy == 0) mà user kéo lên thì bỏ qua luôn, không làm gì cả.
    if (details.delta.dy < 0 && _dragDy <= 0) return;
    _dragDy = (_dragDy + details.delta.dy).clamp(0.0, 260.0);
    widget.onDragUpdate?.call(_dragDy);
  }

  void _onVerticalDragEnd(DragEndDetails details) {
    final velocity = details.primaryVelocity ?? 0;
    widget.onDragEnd?.call(_dragDy, velocity);
    _dragDy = 0;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onDoubleTapDown: (d) => _handleDoubleTap(d, constraints),
          onDoubleTap: () {}, // bắt buộc để onDoubleTapDown hoạt động
          onVerticalDragUpdate: _onVerticalDragUpdate,
          onVerticalDragEnd: _onVerticalDragEnd,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              widget.child,
              ..._hearts.map((h) => _AnimatedHeart(
                dxRatio: h.dx,
                xJitter: h.startOffset,
                icon: widget.icon,
                color: widget.color,
              )),
            ],
          ),
        );
      },
    );
  }
}

class _AnimatedHeart extends StatefulWidget {
  final double dxRatio;
  final double xJitter;
  final IconData icon;
  final Color color;

  const _AnimatedHeart({
    required this.dxRatio,
    required this.xJitter,
    required this.icon,
    required this.color,
  });

  @override
  State<_AnimatedHeart> createState() => _AnimatedHeartState();
}

class _AnimatedHeartState extends State<_AnimatedHeart>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _rise;
  late final Animation<double> _fade;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    )..forward();

    _rise = Tween<double>(begin: 0, end: -110)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _fade = Tween<double>(begin: 1, end: 0).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1.0)));
    _scale = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.4, end: 1.3), weight: 40),
      TweenSequenceItem(tween: Tween(begin: 1.3, end: 1.0), weight: 60),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        return Positioned.fill(
          child: FractionallySizedBox(
            widthFactor: 1,
            heightFactor: 1,
            child: Align(
              alignment: Alignment(widget.dxRatio * 2 - 1, 0.3),
              child: Transform.translate(
                offset: Offset(widget.xJitter, _rise.value),
                child: Opacity(
                  opacity: _fade.value,
                  child: Transform.scale(
                    scale: _scale.value,
                    child: Icon(widget.icon, color: widget.color, size: 64),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// =============================================================================
// HERO PRODUCT IMAGE — dùng bên ShopPage (file khác) để khớp Hero tag
// với ảnh đầu tiên trong carousel ở trên.
//
// Trong ShopPage, chỗ hiển thị ảnh sản phẩm trong list, thay:
//
//   CachedNetworkImage(imageUrl: product["images"][0]["src"], width: 80, height: 80, ...)
//
// bằng:
//
//   Hero(
//     tag: 'product-image-${product["id"]}',
//     child: ClipRRect(
//       borderRadius: BorderRadius.circular(12),
//       child: CachedNetworkImage(
//         imageUrl: product["images"][0]["src"],
//         width: 80,
//         height: 80,
//         fit: BoxFit.cover,
//       ),
//     ),
//   )
//
// Tag PHẢI giống hệt tag dùng ở _buildImageSlide() phía trên
// ('product-image-${widget.product["id"]}').
// =============================================================================